from otree.api import *

import random

doc = """
Your app description
"""


class C(BaseConstants):
	NAME_IN_URL = 'faillo_content'
	PLAYERS_PER_GROUP = 4
	NUM_ROUNDS = 3
	CONVERTED_PRICES = [0.0875,0.15589872,0.22429744,0.29269617,0.36109489,0.42949361,0.49789233,0.56629105,0.63468978,0.7030885]
	ALPHA_1 = 1.5
	ALPHA_2 = 1
	D = 0.3
	GAMMA = 0.2
	MUA = 14
	MUB = 14
	H_NZR = [2.65,2.70,2.7988]
	H_ZR2 = [2.68,2.70,2.8270] # aggiunto
	H_ZR1 = [2.7486,2.80,2.9114] # aggiunto
	C_A = 0.02 # aggiunto
	C_B = 0.02 # aggiunto
	T = [0.29,0.26,0.2375]


class Subsession(BaseSubsession):
	pass


class Group(BaseGroup):
	pass


class Player(BasePlayer):
	roles = models.StringField(initial="")
	price_content_1 = models.IntegerField(initial=0,min=1,max=10)
	price_content_2 = models.IntegerField(initial=0,min=1,max=10)
	tarif_service_1 = models.IntegerField(initial=0)
	tarif_service_2 = models.IntegerField(initial=0)
	start_service = models.IntegerField(initial=0,min=1,max=2)
	second_service = models.IntegerField(initial=0,min=1,max=2)
	id_content_first = models.StringField(initial="")
	id_content_second = models.StringField(initial="")
	id_content = models.StringField(initial ="")
	profit = models.FloatField(initial=0)  #nuovo
	available_content_second = models.StringField(initial="")

	q1A = models.FloatField(initial=0)
	q2A = models.FloatField(initial=0)
	q1B = models.FloatField(initial=0)
	q2B = models.FloatField(initial=0)

	u_A = models.FloatField(initial=0)
	u_B = models.FloatField(initial=0)

	winner = models.IntegerField(initial=0)



#############################################################################
# 								Function
#############################################################################
#----------------------------------------------------------------------------
def creating_session(subsession: Subsession):
	session = subsession.session
	# subsession.group_randomly()
	c = random.choice(['service_1','service_2'])
	for p in subsession.get_players():
		if p.id_in_group < 3:
			p.roles = 'service_' + str(p.id_in_group)
		else:
			p.roles = 'content_' + str(p.id_in_group - 2)

		p.start_service = c
		if p.start_service == 'service_1':
			p.second_service = 'service_2'
		else:
			p.second_service = 'service_1'

		p.participant.vars['cum_payoff'] = 0
		p.participant.vars['history'] = ""


def get_demand(group: Group):
	for p in group.get_players():
		if p.roles == 'service_1':
			p_sp1 = p
		elif p.roles == 'service_2':
			p_sp2 = p
		elif p.roles == 'content_1':
			p_cp1 = p
		else :
			p_cp2 = p


	cp1_price = C.CONVERTED_PRICES[p_cp1.price_content_1 - 1]
	cp2_price = C.CONVERTED_PRICES[p_cp2.price_content_2 - 1]

	if p_sp1.id_content == 'nobody' and p_sp2.id_content == 'nobody':
		teta = [0.29,0.26,0.2375]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		print("tauspa", teta[p_sp1.tarif_service_1 - 1])
	elif p_sp1.id_content == 'content_1' and p_sp2.id_content == 'nobody':
		teta = [0.1526,0.09,0.02]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price - teta[p_sp1.tarif_service_1 - 1]) - ( 1- C.GAMMA ) * C.D   )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1]  )
		teta = [0.29,0.26,0.2375]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )


	elif p_sp1.id_content == 'content_2' and p_sp2.id_content == 'nobody':
		teta = [0.35,0.26,0.2785]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1- C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1])
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price - teta[p_sp1.tarif_service_1 - 1])  - ( 1- C.GAMMA ) * C.D   )
		teta = [0.29,0.26,0.2375]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )


	elif p_sp1.id_content == 'nobody' and p_sp2.id_content == 'content_1':
		teta = [0.29,0.26,0.2375]

		print("***************",cp1_price,cp2_price,p_sp1.tarif_service_1 - 1,p_sp1.tarif_service_2 - 1,teta[p_sp1.tarif_service_1 - 1])
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D)  )
		teta = [0.1526,0.09,0.02]
		print("------------",cp1_price,cp2_price,p_sp1.tarif_service_1 - 1,p_sp1.tarif_service_2 - 1,teta[p_sp2.tarif_service_2 - 1])
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	elif p_sp1.id_content == 'nobody' and p_sp2.id_content == 'content_2':
		teta = [0.29,0.26,0.2375]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		teta = [0.35,0.26,0.2785]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )


	elif p_sp1.id_content == 'content_1' and p_sp2.id_content == 'content_2':
		teta = [0.1526,0.09,0.02]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price - teta[p_sp1.tarif_service_1 - 1]) - ( 1- C.GAMMA ) * C.D   )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1]  )
		teta = [0.35,0.26,0.2785]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	elif p_sp1.id_content == 'content_2' and p_sp2.id_content == 'content_1':
		teta = [0.35,0.26,0.2785]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1- C.GAMMA ) * C.D   - teta[p_sp1.tarif_service_1 - 1])
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price - teta[p_sp1.tarif_service_1 - 1])  - ( 1- C.GAMMA ) * C.D   )
		teta = [0.1526,0.09,0.02]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	if q1A < 0:
		q1A = 0
	if q2A < 0:
		q2A = 0
	if q1B < 0:
		q1B = 0
	if q2B < 0:
		q2B = 0

	for p in group.get_players():
		p.q1A = q1A
		p.q2A = q2A
		p.q1B = q1B
		p.q2B = q2B
	print('DEMAND:',q1A,q2A,q1B,q2B)

	# CALCOLO UTILITA SP1 (A)
	if p_sp1.id_content == 'content_1':
		teta2 = [0.1526,0.09,0.02]
		teta1 = [0,0,0]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_ZR1[p_sp1.tarif_service_1 - 1] + ( teta1[p_sp1.tarif_service_1 - 1] * q1A + teta2[p_sp1.tarif_service_1 - 1] * q2A )  )
	elif p_sp1.id_content == 'content_2':
		teta1 = [0.35,0.26,0.2785]
		teta2 = [0,0,0]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_ZR2[p_sp1.tarif_service_1 - 1] + ( teta1[p_sp1.tarif_service_1 - 1] * q1A + teta2[p_sp1.tarif_service_1 - 1] * q2A )  )
	else: #nzr
		teta = [0.29,0.26,0.2375]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_NZR[p_sp1.tarif_service_1 - 1] + ( teta[p_sp1.tarif_service_1 - 1] * q1A + teta[p_sp1.tarif_service_1 - 1] * q2A )  )

	u_1_A =  C.ALPHA_1 * q1A -  1/2 * (q1A**2) + C.ALPHA_2 * q2A - 1/2 * (q2A**2) - C.GAMMA * q1A * q2A
	u_3_A = ( C.D *(C.MUA - (q1A + q2A) ) )

	u_A = u_1_A - u_2_A + u_3_A
	print ("u1a", u_1_A, "u2a",u_2_A, "u3a",u_3_A)
	# CALCOLO UTILITA SP2 (B)
	if p_sp2.id_content == 'content_1':
		teta2 = [0.1526,0.09,0.02]
		teta1 = [0,0,0]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_ZR1[p_sp2.tarif_service_2 - 1] + ( teta1[p_sp2.tarif_service_2 - 1] * q1B + teta2[p_sp2.tarif_service_2 - 1] * q2B )  )
	elif p_sp2.id_content == 'content_2':
		teta1 = [0.35,0.26,0.2785]
		teta2 = [0,0,0]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_ZR2[p_sp2.tarif_service_2 - 1] + ( teta1[p_sp2.tarif_service_2 - 1] * q1B + teta2[p_sp2.tarif_service_2 - 1] * q2B )  )
	else:
		teta = [0.29,0.26,0.2375]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_NZR[p_sp2.tarif_service_2 - 1] + ( teta[p_sp2.tarif_service_2 - 1] * q1B + teta[p_sp2.tarif_service_2 - 1] * q2B )  )

	u_1_B =  C.ALPHA_1 * q1B -  1/2 * (q1B**2) + C.ALPHA_2 * q2B - 1/2 * (q2B**2) - C.GAMMA * q1B * q2B
	u_3_B = ( C.D * (C.MUB - (q1B + q2B) ) )

	u_B = u_1_B - u_2_B + u_3_B
	print ("u1b", u_1_B, "u2b",u_2_B, "u3b",u_3_B)


	# winner
	if u_A > u_B:
		win = 1
	elif u_A == u_B:
		win = Random.integer(1,2)
	else:
		win = 2

	for p in group.get_players():
		p.u_A = u_A
		p.u_B = u_B
		p.winner = win
		set_payoff(p)





def set_payoff(player: Player):
	H_TARIF = [15,25,38]
	T = [1,0.5,0.25]

#CP
	if player.roles == 'content_1':
			cp1_price = C.CONVERTED_PRICES[player.price_content_1 - 1]
			player.profit = 2733.98*(player.q1A*cp1_price + player.q1B*cp1_price) - 113

	elif player.roles == 'content_2':
			cp2_price = C.CONVERTED_PRICES[player.price_content_2 - 1]
			player.profit = (player.q2A*cp2_price + player.q2B*cp2_price)*1000

#ISP
	else:
		if player.roles == 'service_1' and player.winner == 1:
			if player.id_content == 'nobody':
				teta=[0.29,0.26,0.2375]
				player.profit= 10387*(C.H_NZR[player.tarif_service_1 - 1] + teta[player.tarif_service_1 - 1]*player.q1A + teta[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5130
			elif player.id_content == 'content_1':
				teta2 = [0.1526,0.09,0.02]
				teta1 = [0,0,0]
				player.profit= 10387*(C.H_ZR1[player.tarif_service_1 - 1] + teta1[player.tarif_service_1 - 1]*player.q1A + teta2[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5130
			elif player.id_content == 'content_2':
				teta1 = [0.35,0.26,0.2785]
				teta2 = [0,0,0]
				player.profit= 10387*(C.H_ZR2[player.tarif_service_1 - 1] + teta1[player.tarif_service_1 - 1]*player.q1A + teta2[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5130
		elif player.roles == 'service_1' and player.winner == 2:
				player.profit = 0
		elif player.roles == 'service_2' and player.winner ==2:
			if player.id_content == 'nobody':
				teta=[0.29,0.26,0.2375]
				player.profit= 10387*(C.H_NZR[player.tarif_service_2 - 1] + teta[player.tarif_service_2 - 1]*player.q1B + teta[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5130
			elif player.id_content == 'content_1':
				teta2 = [0.1526,0.09,0.02]
				teta1 = [0,0,0]
				player.profit= 10387*(C.H_ZR1[player.tarif_service_2 - 1] + teta1[player.tarif_service_2 - 1]*player.q1B + teta2[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5130
			elif player.id_content == 'content_2':
				teta1 = [0.35,0.26,0.2785]
				teta2 = [0,0,0]
				player.profit= 10387*(C.H_ZR2[player.tarif_service_2 - 1] + teta1[player.tarif_service_2 - 1]*player.q1B + teta2[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5130
		elif player.roles == 'service_2' and player.winner == 1:
					player.profit = 0


	player.participant.vars['cum_payoff'] = player.participant.vars['cum_payoff'] + player.profit

#############################################################################
# 								Pages
#############################################################################
#----------------------------------------------------------------------------

class FirstZeroOffer(Page):
	form_model = 'player'
	form_fields = ['id_content_first']

	@staticmethod
	def is_displayed(player):
		return player.roles == player.start_service

	@staticmethod
	def before_next_page(player,timeout_happened):
		player.id_content = player.id_content_first
		if player.id_content_first == 'content_1':
			player.available_content_second = 'content_2'
		elif player.id_content_first == 'content_2':
			player.available_content_second = 'content_1'
		else:
			player.available_content_second = 'nobody'


		for p in player.get_others_in_group():
			p.id_content_first = player.id_content_first
			p.available_content_second = player.available_content_second

	@staticmethod
	def vars_for_template(player):
		return dict(
			n = player.roles[len(player.roles)-1]
		)

#----------------------------------------------------------------------------

class TurnWait(WaitPage):
	pass

#----------------------------------------------------------------------------
class SecondZeroOffer(Page):
	form_model = 'player'
	form_fields = ['id_content_second']

	@staticmethod
	def is_displayed(player):
		return player.roles == player.second_service

	@staticmethod
	def vars_for_template(player):
		if player.available_content_second == 'content_1':
			t = " <option value=\"content_1\">Fornitore di contenuti 1</option> <option value=\"nobody\">Nessuno</option>   "
		elif player.available_content_second == 'content_2':
			t = " <option value=\"content_2\">Fornitore di contenuti 2</option> <option value=\"nobody\">Nessuno</option>   "
		else:
			t = " <option value=\"content_1\">Fornitore di contenuti 1</option> <option value=\"content_2\">Fornitore di contenuti 2</option> <option value=\"nobody\">Nessuno</option>   "
		return dict(
			options = t,
			n = player.roles[len(player.roles)-1]
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		player.id_content = player.id_content_second
		for p in player.get_others_in_group():
			p.id_content_second = player.id_content_second


#----------------------------------------------------------------------------
class TarifChoice(Page):
	form_model = 'player'

	@staticmethod
	def get_form_fields(player):
		if player.roles == 'service_1':
			rt = ['tarif_service_1']
		else:
			rt = ['tarif_service_2']
		return rt

	@staticmethod
	def is_displayed(player):
		return player.roles == 'service_1' or player.roles == 'service_2'

	@staticmethod
	def vars_for_template(player):
		if player.roles == player.start_service:
			key = player.id_content_first
		else:
			key = player.id_content_second

		tariffa_1 = 'Tariffa 1-15GB: 15 punti al mese + 1 punto per ogni GB extra da fornitore di contenuti 1 + 1 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_2 = 'Tariffa 2-20GB: 25 punti al mese + 0.5 punto per ogni GB extra da fornitore di contenuti 1 + 0.5 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_3 = 'Tariffa 3-25GB: 38 punti al mese + 0.25 punto per ogni GB extra da fornitore di contenuti 1 + 0.25 punto per ogni GB extra da fornitore di contenuti 2'

		tariffa_11 = 'Tariffa 1-15GB: 15 punti al mese + 0 punto per ogni GB extra da fornitore di contenuti 1 + 1 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_12 = 'Tariffa 2-20GB: 25 punti al mese + 0 punto per ogni GB extra da fornitore di contenuti 1 + 0.5 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_13 = 'Tariffa 3-25GB: 38 punti al mese + 0 punto per ogni GB extra da fornitore di contenuti 1 + 0.25 punto per ogni GB extra da fornitore di contenuti 2'

		tariffa_21 = 'Tariffa 1-15GB: 15 punti al mese + 1 punto per ogni GB extra da fornitore di contenuti 1 + 0 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_22 = 'Tariffa 2-20GB: 25 punti al mese + 0.5 punto per ogni GB extra da fornitore di contenuti 1 + 0 punto per ogni GB extra da fornitore di contenuti 2'
		tariffa_23 = 'Tariffa 3-25GB: 38 punti al mese + 0.25 punto per ogni GB extra da fornitore di contenuti 1 + 0 punto per ogni GB extra da fornitore di contenuti 2'

		if key == 'nobody':
			t = " <option value=1>" + tariffa_1 + "</option> <option value=2>" + tariffa_2 + "</option>   <option value=3>" + tariffa_3 + "</option> "
		elif key == 'content_1':
			t = " <option value=1>" + tariffa_11 + "</option> <option value=2>" + tariffa_12 + "</option> <option value=3>" + tariffa_13 + "</option>"
		else:
			t = " <option value=1>" + tariffa_21 + "</option> <option value=2>" + tariffa_22 + "</option> <option value=3>" + tariffa_23 + "</option>"

		if player.roles == 'service_1':
			rt = 'tarif_service_1'
		else:
			rt = 'tarif_service_2'
		return dict(
			options = t,
			name_var = rt,
			n = player.roles[len(player.roles)-1]
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		if player.roles == 'service_1':
			for p in player.get_others_in_group():
				p.tarif_service_1 = player.tarif_service_1
		else:
			for p in player.get_others_in_group():
				p.tarif_service_2 = player.tarif_service_2


#----------------------------------------------------------------------------
class ContentPrice(Page):
	form_model = 'player'

	@staticmethod
	def get_form_fields(player):
		if player.roles == 'content_1':
			rt = ['price_content_1']
		else:
			rt = ['price_content_2']
		return rt

	@staticmethod
	def is_displayed(player):
		return player.roles == 'content_1' or player.roles == 'content_2'

	@staticmethod
	def vars_for_template(player):
		if player.roles == 'content_1':
			rt = 'price_content_1'
		else:
			rt = 'price_content_2'

		return dict(
			name_var = rt,
			n = player.roles[len(player.roles)-1]
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		if player.roles == 'content_1':
			for p in player.get_others_in_group():
				p.price_content_1 = player.price_content_1
		else:
			for p in player.get_others_in_group():
				p.price_content_2 = player.price_content_2


#----------------------------------------------------------------------------

class DemandWait(WaitPage):
	wait_for_all_groups = False
	after_all_players_arrive = get_demand

#----------------------------------------------------------------------------
class Debug(Page):
	form_model = 'player'

	@staticmethod
	def vars_for_template(player):
		mygrp = player.group
		get_demand(mygrp)
		return dict(

		)

class Results(Page):

	@staticmethod
	def vars_for_template(player):

		if player.roles == 'content_1':
			ch = player.price_content_1
		elif player.roles == 'content_2':
			ch = player.price_content_2
		elif player.roles == 'service_1':
			ch = player.tarif_service_1
		elif player.roles == 'service_2':
			ch = player.tarif_service_2


		my_tr = "<tr><th>IO:" + player.roles + "</th><td>" + str(ch) + "</td><td>" + str(round(player.profit,2)) + "</td><td>" + str(round(player.participant.vars['cum_payoff'],2)) + "</td></tr>"

		other_tr = ""
		for p in player.get_others_in_group():
			if p.roles == 'content_1':
				ch = player.price_content_1
			elif p.roles == 'content_2':
				ch = player.price_content_2
			elif p.roles == 'service_1':
				ch = player.tarif_service_1
			elif p.roles == 'service_2':
				ch = player.tarif_service_2

			other_tr = other_tr + "<tr><td>" + p.roles + "</td><td>" + str(ch) + "</td><td>" + str(round(p.profit,2)) + "</td><td>" + str(round(p.participant.vars['cum_payoff'],2)) + "</td></tr>"

			


		return dict(
			cumulated = player.participant.vars['cum_payoff'],
			tr = my_tr + other_tr,
			history = player.participant.vars["history"]
		)


	@staticmethod
	def before_next_page(player,timeout_happened):

		if player.roles == 'content_1':
			ch = player.price_content_1
		elif player.roles == 'content_2':
			ch = player.price_content_2
		elif player.roles == 'service_1':
			ch = player.tarif_service_1
		elif player.roles == 'service_2':
			ch = player.tarif_service_2


		my_tr = "<tr><th>IO:" + player.roles + "</th><td>" + str(ch) + "</td><td>" + str(round(player.profit,2)) + "</td><td>" + str(round(player.participant.vars['cum_payoff'],2)) + "</td></tr>"

		other_tr = ""
		for p in player.get_others_in_group():
			if p.roles == 'content_1':
				ch = player.price_content_1
			elif p.roles == 'content_2':
				ch = player.price_content_2
			elif p.roles == 'service_1':
				ch = player.tarif_service_1
			elif p.roles == 'service_2':
				ch = player.tarif_service_2

			other_tr = other_tr + "<tr><td>" + p.roles + "</td><td>" + str(ch) + "</td><td>" + str(round(p.profit,2)) + "</td><td>" + str(round(p.participant.vars['cum_payoff'],2)) + "</td></tr>"


		player.participant.vars['history'] = player.participant.vars['history'] + "<hr>" +  "<tr><th colspan=\"4\">ROUND " + str(player.round_number) + "</th></tr>" + my_tr + other_tr








page_sequence = [FirstZeroOffer,TurnWait,SecondZeroOffer,TurnWait,TarifChoice,ContentPrice,DemandWait,Results]
