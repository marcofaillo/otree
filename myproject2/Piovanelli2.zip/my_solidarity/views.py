from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants

# Show Instructions
class Instructions(Page):
    def is_displayed(self):
        return self.subsession.round_number == 1

# End round trial
class EndTrial(Page):
    def is_displayed(self):
        return self.subsession.round_number == Constants.num_trial + 1


# Show Role
class ShowRole(Page):

    def vars_for_template(self):
        if self.player.id_in_group == 1:
            my_role = 'Datore di lavoro'
        else:
            my_role = 'Lavoratore'

        return {'my_role': my_role}

    def is_displayed(self):
        return self.subsession.round_number == 1

# Contratto proposto
class wageEffort(Page):
    form_model = models.Player
    form_fields = ['asked_tables', 'wage', 'wage_min']

    def asked_tables_choices(self):
        return range(0, 21, 1)

    def wage_choices(self):
        return range(0, 11, 1)

    def wage_min_choices(self):
        return range(0, 11, 1)

    def error_message(self, values):
        if values["wage"] < values["wage_min"]:
            return 'Il salario non può essere minore del salaro minimo!'


    def is_displayed(self):
        return self.player.id_in_group == 1

class SeeContract(Page):
    form_model = models.Player

    def vars_for_template(self):
        wage = self.player.get_L0_wage()
        wagem = self.player.get_L0_wage_min()
        askef = self.player.get_L0_asked_tables()

        return {'wage': wage, 'wagem': wagem, 'asked': askef}



    def is_displayed(self):
        return self.player.id_in_group != 1

# Game for leader
class Game(Page):
    timeout_seconds = Constants.seconds_job

    def is_displayed(self):
        return self.player.id_in_group == 1


class Game2(Page):
    timeout_seconds = Constants.seconds_job

    def is_displayed(self):
        return self.player.id_in_group == 1


# Page to work
class ZeroOne(Page):
    form_model = models.Player
    form_fields = ['completed_tables']

    timeout_seconds = Constants.seconds_job

    def before_next_page(self):
        if self.timeout_happened:
            post_dict = self.request.POST.dict()
            my_value = post_dict.get('completed_tables')
            self.player.completed_tables = int(my_value)

    def is_displayed(self):
        return self.player.id_in_group != 1

    # Show Random Device + send tab
class RandomDevice(Page):
    form_model = models.Player
    form_fields = ['passed1_tables', 'passed2_tables', 'passed3_tables']

    def passed1_tables_choices(self):
            return range(int(0), int((self.player.completed_tables)* Constants.multiplication_factor + 1), int(1))

    def passed2_tables_choices(self):
        return range(int(0), int(self.player.completed_tables + 1), int(1))

    def passed3_tables_choices(self):
        return range(int(0), int(self.player.completed_tables + 1), int(1))


    def vars_for_template(self):

        if self.player.id_in_group == self.player.participant.vars['random_dice'][self.subsession.round_number - 1]:
            return {'ask': self.player.get_L0_asked_tables(),'random_device': 1, 'num_tabs': self.player.completed_tables, 'my_tabs': self.player.completed_tables * 0.5}
        else:
            return {'ask': self.player.get_L0_asked_tables(),'random_device': 0, 'num_tabs': self.player.completed_tables, 'my_tabs': self.player.completed_tables * 0.5}

    def is_displayed(self):
        return self.player.id_in_group != 1

#quante tabelle hai mandato, quante ne ha mandate il tuo coworker
class SendTab(Page):


    def vars_for_template(self):
        numtab = self.player.completed_tables
        other = self.player.get_others_in_group()


        if self.player.id_in_group == 2:
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed3_tables, 'random_device': 0, 'other': other[1].passed3_tables,'num_tabs': numtab}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed1_tables, 'random_device': 1, 'num_tabs': numtab, 'my_tabs': numtab * 0.5, 'other': other[1].passed2_tables }
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed2_tables, 'random_device': 2,'num_tabs': numtab, 'other': other[1].passed1_tables}

        if self.player.id_in_group == 3:
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed3_tables, 'random_device': 0,'num_tabs': numtab, 'other': other[1].passed3_tables}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed2_tables, 'random_device': 1, 'num_tabs': numtab, 'other': other[1].passed1_tables}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
                return {'ask': self.player.get_L0_asked_tables(),'passtab': self.player.passed1_tables, 'random_device': 2, 'num_tabs': numtab, 'my_tabs': numtab * 0.5, 'other': other[1].passed2_tables}

    def is_displayed(self):
        return self.player.id_in_group != 1




#Wait Boss and worker
class EndJobWaitPage(WaitPage):

    def after_all_players_arrive(self):
        pass



# Leader show contrib and punish
class LeaderPunish(Page):
    form_model = models.Player
    form_fields = ['effective_wage1', 'effective_wage2']



    def vars_for_template(self):
        avg_tab = self.player.get_avg_tabs()
        wage = self.player.wage
        wage_min = self.player.wage_min
        asked = self.player.asked_tables

        if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
            return {'tab_1': self.player.get_r1L1_completed_tables(),'tab_2': self.player.get_r1L2_completed_tables(), 'avg': avg_tab, 'asked': asked,'wage': wage, 'wagem': wage_min}
        if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            return {'tab_1': self.player.get_r2L1_completed_tables(),'tab_2': self.player.get_r2L2_completed_tables(), 'avg': avg_tab, 'asked': asked, 'wage': wage, 'wagem': wage_min}
        if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            return {'tab_1': self.player.get_r3L1_completed_tables(),'tab_2': self.player.get_r3L2_completed_tables(), 'avg': avg_tab, 'asked': asked, 'wage': wage, 'wagem': wage_min}

    def effective_wage1_choices(self):
        if self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 1 and self.player.get_r1L1_completed_tables() >= self.player.asked_tables:
            return (self.player.wage, '')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 1 and self.player.get_r1L1_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 2 and self.player.get_r2L1_completed_tables() >= self.player.asked_tables:
            return (self.player.wage,'')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 2 and self.player.get_r2L1_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 3 and self.player.get_r3L1_completed_tables() >= self.player.asked_tables:
            return (self.player.wage,'')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 3 and self.player.get_r3L1_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)

    def effective_wage2_choices(self):
        if self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 1 and self.player.get_r1L2_completed_tables() >= self.player.asked_tables:
            return (self.player.wage,'')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 1 and self.player.get_r1L2_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 2 and self.player.get_r2L2_completed_tables() >= self.player.asked_tables:
            return (self.player.wage,'')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 2 and self.player.get_r2L2_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 3 and self.player.get_r3L2_completed_tables() >= self.player.asked_tables:
            return (self.player.wage,'')
        elif self.player.participant.vars['random_dice'][
                    self.subsession.round_number - 1] == 3 and self.player.get_r3L2_completed_tables() < self.player.asked_tables:
            return (self.player.wage_min, self.player.wage)

    def is_displayed(self):
        return self.player.id_in_group == 1



# Leader Expectations
class LeaderExpectations(Page):
    form_model = models.Player
    form_fields = ['expected_tabs_1','expected_tabs_2']

    def expected_tabs_1_choices(self):
        return range(0, 100, 1)

    def expected_tabs_2_choices(self):
        return range(0, 100, 1)

    def is_displayed(self):
        return self.player.id_in_group == 1

    def before_next_page(self):
        self.group.set_payoff()



class ShowPayoff(Page):
    def vars_for_template(self):
        pp = self.participant.payoff_plus_participation_fee()
        other = self.player.get_others_in_group()
        cum_pay = self.player.get_cum_payoff()
        if self.subsession.round_number <= Constants.num_trial:
            cum_pay = 0
        payoff_round = self.player.payoff_round
        if self.subsession.round_number <= Constants.num_trial:
            payoff_round = 0
        round_prova = False
        if self.subsession.round_number <= Constants.num_trial:
            round_prova = True

        if self.player.id_in_group == 1:
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
                t1 = other[0].completed_tables - other[0].passed3_tables
                t2 = other[1].completed_tables - other[1].passed3_tables
                return {'tab_1': self.player.get_r1L1_completed_tables(), 'tab_2': self.player.get_r1L2_completed_tables(),
                        'l1_tab': t1, 'l2_tab': t2, 'round_prova': round_prova, 'cum_pay': cum_pay,
                        'payoff': payoff_round, 'wage1': self.player.effective_wage1, 'wage2': self.player.effective_wage2}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
                t1 = other[0].completed_tables * 0.5 - other[0].passed1_tables
                t2 = other[1].completed_tables - other[1].passed2_tables
                return {'tab_1': self.player.get_r2L1_completed_tables(),'tab_2': self.player.get_r2L2_completed_tables(),'l1_tab': t1, 'l2_tab': t2, 'round_prova': round_prova, 'cum_pay':cum_pay, 'payoff':payoff_round, 'wage1': self.player.effective_wage1, 'wage2': self.player.effective_wage2}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
                t1 = other[0].completed_tables - other[0].passed2_tables
                t2 = other[1].completed_tables * 0.5  - other[1].passed1_tables
                return {'tab_1': self.player.get_r3L1_completed_tables(),'tab_2': self.player.get_r3L2_completed_tables(),'l1_tab': t1, 'l2_tab': t2, 'round_prova': round_prova, 'cum_pay':cum_pay, 'payoff':payoff_round, 'wage1': self.player.effective_wage1, 'wage2': self.player.effective_wage2}
        if self.player.id_in_group == 2:
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
                return {'wage1': other[0].effective_wage1, 'ask': other[0].asked_tables,'pass': self.player.passed3_tables,'tab23': self.player.get_r1L2L1_completed_tables(), 'round_prova': round_prova, 'cum_pay':cum_pay, 'payoff':payoff_round}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
                return {'wage1': other[0].effective_wage1, 'ask': other[0].asked_tables, 'pass': self.player.passed1_tables, 'tab23': self.player.get_r2L2L1_completed_tables(),
                    'round_prova': round_prova, 'cum_pay': cum_pay, 'payoff': payoff_round}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
                return {'wage1': other[0].effective_wage1, 'ask': other[0].asked_tables, 'pass': self.player.passed2_tables, 'tab23': self.player.get_r3L2L1_completed_tables(),
                    'round_prova': round_prova, 'cum_pay': cum_pay, 'payoff': payoff_round}

        if self.player.id_in_group == 3:
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
                return {'wage2': other[0].effective_wage2, 'ask': other[0].asked_tables,'pass': self.player.passed3_tables,'tab32': self.player.get_r1L1L2_completed_tables(), 'round_prova': round_prova, 'cum_pay':cum_pay, 'payoff':payoff_round}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
                return {'wage2': other[0].effective_wage2, 'ask': other[0].asked_tables, 'pass': self.player.passed2_tables, 'tab32': self.player.get_r2L1L2_completed_tables(),
                         'round_prova': round_prova, 'cum_pay': cum_pay, 'payoff': payoff_round}
            if self.player.participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
                return {'wage2': other[0].effective_wage2,'ask': other[0].asked_tables,'pass': self.player.passed1_tables, 'tab32': self.player.get_r3L1L2_completed_tables(),
                        'round_prova': round_prova, 'cum_pay': cum_pay, 'payoff': payoff_round}


#Wait All players
class EndRoundWaitPage(WaitPage):
    wait_for_all_groups = True
    def after_all_players_arrive(self):
        pass

#Final Pay
class ShowPayoffFinal(Page):
    def vars_for_template(self):
        cum_pay = self.player.get_cum_payoff()
        if self.player.id_in_group == 2:
            cum_pay = cum_pay
        if self.player.id_in_group == 3:
            cum_pay = cum_pay 
        if self.player.id_in_group == 1:
            cum_pay = cum_pay
        final_pay = self.participant.payoff_plus_participation_fee()
        return {'total_payoff':final_pay, 'cum_pay': cum_pay}

    def is_displayed(self):
        return self.subsession.round_number == Constants.num_rounds


page_sequence = [
    EndTrial,
    Instructions,
    ShowRole,
    wageEffort,
    EndJobWaitPage,
    SeeContract,
    EndJobWaitPage,
    Game2,
    ZeroOne,
    RandomDevice,
    EndJobWaitPage,
    SendTab,
    LeaderPunish,
    LeaderExpectations,
    EndJobWaitPage,
    ShowPayoff,
    EndRoundWaitPage,
    ShowPayoffFinal,
]
