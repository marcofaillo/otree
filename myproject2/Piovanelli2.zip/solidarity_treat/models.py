from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


author = 'Piovanelli Faillo'

doc = """
solidarity con trattamento
"""


class Constants(BaseConstants):
    name_in_url = 'solidarity_treat'
    players_per_group = 3
    num_rounds = 12
    num_trial = 2
    seconds_job = 90
    multiplication_factor = 0.5

class Subsession(BaseSubsession):
    def before_session_starts(self):
        self.session.config['participation_fee'] = 3
        self.session.config['real_world_currency_per_point'] = 0.05
        if self.round_number < Constants.num_trial + 1:
            self.group_randomly(fixed_id_in_group=True)
        if self.round_number == 1:
            for player in self.get_players():
                player.participant.vars['random_dice'] = [3, 2, 3, 1, 1, 3, 2, 3, 1, 1, 3, 2, 3, 1, 1, 3, 2, 3, 1, 1, 3, 2, 3, 1, 1]
                # 1 no random device, 2 random device al giocatore 2, 3 random device al giocatore 3


class Group(BaseGroup):
    def set_payoff(self):
        pl = self.get_players()


        # payoff leader
        leader_pay = 20 - pl[0].effective_wage1 - pl[0].effective_wage2


        ##tabs completed
        mt1 = pl[1].completed_tables
        if pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            mt1 = mt1 * 0.5
            if mt1 < 0:
                mt1 = 0
        tabs_completed1 = mt1

        mt2 = pl[2].completed_tables
        if pl[2].participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            mt2 = mt2 * 0.5
            if mt2 < 0:
                mt2 = 0
        tabs_completed2 = mt2

        ##tabs received

        nt1 = 0
        if pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
            nt1 = pl[1].passed3_tables + pl[2].passed3co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            nt1 = pl[1].passed1_tables + pl[2].passed2co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            nt1 = pl[1].passed2_tables + pl[2].passed1co_tables
        tabs_received1 = nt1

        nt2 = 0
        if pl[2].participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
            nt2 = pl[2].passed3_tables + pl[1].passed3co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            nt2 = pl[2].passed2_tables + pl[1].passed1co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            nt2 = pl[2].passed1_tables + pl[1].passed2co_tables
        tabs_received2 = nt2

        mt1 = 0
        if pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
            mt1 = pl[1].passed3_tables + pl[1].passed3co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            mt1 = pl[1].passed1_tables + pl[1].passed1co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            mt1 = pl[1].passed2_tables + pl[1].passed2co_tables
        tabs_given1 = mt1

        mt2 = 0
        if pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 1:
            mt2 = pl[2].passed3_tables + pl[2].passed3co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 2:
            mt2 = pl[2].passed2_tables + pl[2].passed2co_tables
        elif pl[1].participant.vars['random_dice'][self.subsession.round_number - 1] == 3:
            mt2 = pl[2].passed1_tables + pl[2].passed1co_tables
        tabs_given2 = mt2


        tabs_pay1 = tabs_received1
        if tabs_pay1 < 0:
            tabs_pay1 = 0

        tabs_pay2 = tabs_received2
        if tabs_pay2 < 0:
            tabs_pay2 = 0

        tabs_pay = (tabs_pay1 + tabs_pay2) * 0.6
        leader_pay = leader_pay + tabs_pay

        ##expected tabs
        if pl[0].expected_tabs_1 == (tabs_completed1 - tabs_given1) and pl[0].expected_tabs_2 == (tabs_completed2 - tabs_given2):
            leader_pay = leader_pay + 2
        elif pl[0].expected_tabs_1 == (tabs_completed1 - tabs_given1) or pl[0].expected_tabs_2 == (tabs_completed2 - tabs_given2):
            leader_pay = leader_pay + 1

        pl[0].payoff_round = leader_pay
        if self.subsession.round_number > Constants.num_trial:
            pl[0].payoff = leader_pay
        else:
            pl[0].payoff = 0

        # payoff worker 1



        worker_1_pay = 8 + pl[0].effective_wage1 + (tabs_completed1 - tabs_given1) * 0.4
        pl[1].payoff_round = worker_1_pay
        if self.subsession.round_number > Constants.num_trial:
            pl[1].payoff = worker_1_pay
        else:
            pl[1].payoff = 0

        # payoff worker 2


        worker_2_pay = 8 + pl[0].effective_wage2 + (tabs_completed2 - tabs_given2) * 0.4
        pl[2].payoff_round = worker_2_pay
        if self.subsession.round_number > Constants.num_trial:
            pl[2].payoff = worker_2_pay
        else:
            pl[2].payoff = 0

            # print("PAYOFF",pl[0].payoff,pl[1].payoff,pl[2].payoff)


class Player(BasePlayer):
    # vars for role 1 boss

    # vars for role 2/3 worker
    completed_tables = models.IntegerField(doc="Numero Tabelle Completate")
    passed1_tables = models.FloatField(doc="Numero Tabelle passate al datore di lavoro")
    passed2_tables = models.FloatField(doc="Numero Tabelle passate al datore di lavoro")
    passed3_tables = models.FloatField(doc="Numero Tabelle passate al datore di lavoro")
    passed1co_tables = models.FloatField(doc="Numero Tabelle passate all'altro lavoratore")
    passed2co_tables = models.FloatField(doc="Numero Tabelle passate all'altro lavoratore")
    passed3co_tables = models.FloatField(doc="Numero Tabelle passate all'altro lavoratore")
    expected_tabs_1 = models.IntegerField(doc="Numero Tabelle trattenute dal lavoratore 1")
    expected_tabs_2 = models.IntegerField(doc="Numero Tabelle trattenute dal lavoratore 2")
    payoff_round = models.CurrencyField()
    wage = models.IntegerField(doc="Salario")
    wage_min = models.IntegerField(doc="Salario minimo")
    asked_tables = models.IntegerField(doc="Tabelle richieste")
    effective_wage1 = models.IntegerField(doc="Salario scelto per il lavoratore 1")
    effective_wage2 = models.IntegerField(doc="Salario scelto per il lavoratore 2")

    q_1 = models.IntegerField()
    q_2 = models.IntegerField()
    q_3 = models.IntegerField()


    # num tab other worker
    def get_other_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].completed_tables
        return nt

    # num tab to leader worker 1 per leader
    def get_L1_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[0].passed_tables

        return nt

    # num tab to leader worker 1 per worker2
    def get_L0_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed_tables

        return nt

    # num tab to leader worker 2
    def get_L2_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed_tables

        return nt

    # salario del datore per lav
    def get_L0_wage(self):
        mg = self.get_others_in_group()
        nt = mg[0].wage
        return nt

    # salario min del datore per lav
    def get_L0_wage_min(self):
        mg = self.get_others_in_group()
        nt = mg[0].wage_min
        return nt

    # tabelle richieste del datore per lav
    def get_L0_asked_tables(self):
        mg = self.get_others_in_group()
        nt = mg[0].asked_tables
        return nt

    # num tab che l'altro lavoratore mi ha passato
    def get_other_passed_co_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed_co_tables
        return nt

    # num tab che il lavoratore 1 ha passato al 2 (da parte del datore)
    def get_L1_passed_co_tables(self):
        mg = self.get_others_in_group
        nt = int(mg[0].passed_co_tables)
        return nt

    # num tab che il lavoratore 2 ha passato al 1 (da parte del datore)
    def get_L2_passed_co_tables(self):
        mg = self.get_others_in_group()
        nt = int(mg[1].passed_co_tables)
        return nt

    # num tab che il lavoratore 1 ha passato al 2 (da parte del lavoratore 2)
    def get_L1_passedme_co_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed_co_tables
        return nt

    # num tab che il lavoratore 2 ha passato al 1 (da parte del lavoratore 1)
    def get_L2_passedme_co_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed_co_tables
        return nt

     # num tab to leader worker 1 random device = 1 per dat
    def get_r1L1_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[0].passed3_tables
        nt = mg[1].passed3co_tables + mt
        return nt

    # num tab to leader worker 2 random device = 1 per dat
    def get_r1L2_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[1].passed3_tables
        nt = mg[0].passed3co_tables + mt
        return nt

    # num tab to leader worker 1 random device = 2 per dat
    def get_r2L1_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[0].passed1_tables
        nt = mg[1].passed2co_tables + mt
        return nt

    # num tab to leader worker 2 random device = 2 per dat
    def get_r2L2_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[1].passed2_tables
        nt = mg[0].passed1co_tables + mt
        return nt

    # num tab to leader worker 1 random device = 3 per dat
    def get_r3L1_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[0].passed2_tables
        nt = mg[1].passed1co_tables + mt
        return nt

    # num tab to leader worker 2 random device = 3 per dat
    def get_r3L2_completed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[1].passed1_tables
        nt = mg[0].passed2co_tables + mt
        return nt

    # num tab totali ricevute da datore da lav 1 (da parte datore)
    def get_L1_tot_passed_tables (self):
        mg = self.get_others_in_group()
        mt = mg[0].passed_tables

        nt = mg[1].passed_co_tables + mt

        return nt

     # num tab totali ricevute da datore da lav 2 (da parte datore)
    def get_L2_tot_passed_tables(self):
        mg = self.get_others_in_group()
        mt = mg[1].passed_tables

        nt = mg[0].passed_co_tables + mt


        return nt

    # num tab to leader worker 1 random device = 1 per work2

    def get_r1L1L2_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed3_tables
        return nt

    # num tab to leader worker 2 random device = 1 per work1
    def get_r1L2L1_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed3_tables
        return nt

        # num tab to leader worker 1 random device = 2 per work2

    def get_r2L1L2_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed1_tables
        return nt

        # num tab to leader worker 2 random device = 2 per work1

    def get_r2L2L1_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed2_tables
        return nt

        # num tab to leader worker 1 random device = 3 per work2

    def get_r3L1L2_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed2_tables
        return nt

        # num tab to leader worker 2 random device = 3 per work1

    def get_r3L2L1_completed_tables(self):
        mg = self.get_others_in_group()
        nt = mg[1].passed1_tables
        return nt

    # average tables per datore PER OGNI ROUND
    def get_avg_tabs(self):
        avg_tabs = 0
        somma = 0
        comp = 0
        gb = 0
        print('ciao')
        if self.round_number > 1:
            for p in self.subsession.get_players():
                print(p.payoff)
                comp = 0
                if p.role() == 'Lavoratore':
                    comp = p.in_round(self.round_number - 1).completed_tables
                    print("comp", comp)
                    gb = gb + 1
                # print("gb",gb)
                somma = somma + comp
                print("somma", somma)
            avg_tabs = avg_tabs + (somma / gb)
        else:
            avg_tabs = 0
        print('avg', avg_tabs)
        return avg_tabs


    # Cumulated Payoff
    def get_cum_payoff(self):
        cum_pay = 0
        old_round = self.in_rounds(Constants.num_trial + 1, Constants.num_rounds)
        for p in old_round:
            cum_pay = cum_pay + p.payoff
        self.participant.vars['cumulated_payoff_phase_1'] = cum_pay
        return cum_pay



    def role(self):
        if self.id_in_group == 1:
            return 'Datore di lavoro'
        else:
            return 'Lavoratore'
