# -*- coding: utf-8 -*-
# <standard imports>
from __future__ import division

import random

import otree.models
from otree.db import models
from otree import widgets
from otree.common import Currency as c, currency_range, safe_json
from otree.constants import BaseConstants
from otree.models import BaseSubsession, BaseGroup, BasePlayer

# </standard imports>

author = 'Felix Holzmeister & Armin Pfurtscheller'

doc = """
Bomb Risk Elicitation Task (BRET) à la Crosetto/Filippin (2013), Journal of Risk and Uncertainty (47): 31-65.
"""

class Constants(BaseConstants):

	# oTree Constants
	name_in_url = 'bret_ita'
	players_per_group = None
	box_value = 2
	num_rows = 10
	num_cols = 10
	box_height = '30px'
	box_width = '30px'
	num_rounds = 1
	endowment = 120

	# determines whether all rounds played are payed-off or whether one round is randomly chosen for payment
	# if <random_payoff = True>, one round is randomly determined for payment
	# if <random_payoff = False>, the final payoff of the task is the sum of all rounds played
	# note that this is only of interest for the case of <num_rounds> larger than 1
	random_payoff = True

	# if <instructions = True>, a separate template "Instructions.html" is rendered prior to the task in round 1
	# if <instructions = False>, the task starts immediately (e.g. in case of printed instructions)
	instructions = True

	# show feedback by resolving boxes, i.e. toggle boxes and show whether bomb was collected or not
	# if <feedback = True>, the button "Solve" will be rendered and active after game play ends ("Stop")
	# if <feedback = False>, the button "Solve" won't be rendered such that no feedback about game outcome is provided
	feedback = True

	# show results page summarizing the game outcome
	# if <results = True>, a separate page containing all relevant information is displayed after finishing the task
	# if <num_rounds> larger than 1, results are summarized in a table and only shown after all rounds have been played
	results = True


	# ---------------------------------------------------------------------------------------------------------------- #
	# --- Settings Determining Game Play --- #
	# ---------------------------------------------------------------------------------------------------------------- #

	# "dynamic" or "static" game play
	# if <dynamic = True>, one box per time interval is collected automatically
	# in case of <dynamic = True>, game play is affected by the variables <time_interval> and <random> below
	# if <dynamic = False>, subjects collect as many boxes as they want by clicking or entering the respective number
	# in case of <dynamic = False>, game play is affected by the variables <random>, <devils_game> and <undoable>
	dynamic = False

	# time interval between single boxes being collected (in seconds)
	# note that this only affects game play if <dynamic = True>
	time_interval = 1.00

	# collect boxes randomly or systematically
	# if <random = False>, boxes are collected row-wise one-by-one, starting in the top-left corner
	# if <random = True>, boxes are collected randomly (Fisher-Yates Algorithm)
	# note that this affects game play in both cases, <dynamic = True> and <dynamic = False>
	random = True

	# determines whether static game play allows for selecting boxes by clicking or by entering a number
	# if <devils_game = True>, game play is similar to Slovic (1965), i.e. boxes are collected by subjects
	# if <devils_game = False>, subjects enter the number of boxes they want to collect
	# note that this only affects game play if <dynamic = False>
	devils_game = True

	# determine whether boxes can be toggled only once or as often as clicked
	# if <undoable = True> boxes can be selected and de-selected indefinitely often
	# if <undoable = False> boxes can be selected only once (i.e. decisions can not be undone)
	# note that this only affects game play if <dynamic = False> and <devils_game = True>
	undoable = True

# ******************************************************************************************************************** #
# *** CLASS SUBSESSION *** #
# ******************************************************************************************************************** #
class Subsession(BaseSubsession):
	pass

# ******************************************************************************************************************** #
# *** CLASS GROUP *** #
# ******************************************************************************************************************** #
class Group(BaseGroup):
	# <built-in>
	subsession = models.ForeignKey(Subsession)
	# </built-in>


# ******************************************************************************************************************** #
# *** CLASS PLAYER *** #
# ******************************************************************************************************************** #
class Player(BasePlayer):
  # <built-in>
	subsession = models.ForeignKey(Subsession)
	group = models.ForeignKey(Group, null=True)
	# </built-in>

	# whether bomb is collected or not
	bomb = models.IntegerField()

	# location of bomb with row/col info
	bomb_location = models.TextField()

	# number of collected boxes
	boxes_collected = models.IntegerField()

	# set/scheme of collected boxes
	boxes_scheme = models.TextField()


	# --- set round results and player's payoff
	# ------------------------------------------------------------------------------------------------------------------
	round_to_pay = models.IntegerField()
	round_result = models.CurrencyField()
	pay = models.CurrencyField()
	def set_payoff(self):

	# randomly determine round to pay on player level
		if self.subsession.round_number == 1:
			self.session.vars['round_to_pay'] = random.randint(1,Constants.num_rounds)

		# determine round_result as (potential) payoff per round
		if self.bomb == 0:
			self.round_result = c(self.boxes_collected * Constants.box_value)
		else:
			self.round_result = c(0)

		# set payoffs if <random_payoff = True> to round_result of randomly chosen round
		if Constants.random_payoff == True:
			if self.subsession.round_number == self.session.vars['round_to_pay']:
				self.pay = self.round_result
			else:
				self.pay = c(0)


		# set payoffs to round_result if <random_payoff = False>
		else:
			self.pay = self.round_result
		self.participant.vars['payoff_bret'] = self.pay

	# --- store values as global variables for session-wide use
	# ------------------------------------------------------------------------------------------------------------------
	def set_globals(self):
		self.session.vars['bomb'] = [p.bomb for p in self.in_all_rounds()]
		self.session.vars['bomb_location'] = [p.bomb_location for p in self.in_all_rounds()]
		self.session.vars['boxes_collected'] = [p.boxes_collected for p in self.in_all_rounds()]
		self.session.vars['boxes_scheme'] = [p.boxes_scheme for p in self.in_all_rounds()]
		self.session.vars['round_result'] = [p.round_result for p in self.in_all_rounds()]
		self.session.vars['bret_payoff'] = [p.payoff for p in self.in_all_rounds()]
