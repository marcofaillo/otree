from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
    )
import random as r
import json
from otree.api import safe_json

author = 'Marco Faillo + Marco Tecilla and Felix Holzmeister & Armin Pfurtscheller (BRET)'


doc = """
Lottery tasks to measure choiceoverload impact on decision making (treatment with 5 numbers) with BRET before
"""


class Constants(BaseConstants):
    name_in_url = 'parodox_bret'
    players_per_group = None
    num_rounds = 1
    ex = 0.01
    show_up= 1
    #bret
    box_value = 1
    num_rows = 10
    num_cols = 10
    box_height = '30px'
    box_width = '30px'
    random_payoff = True
    instructions = True
    feedback = True
    results = True
    dynamic = False
    time_interval = 1.00
    random = True
    devils_game = False
    undoable = True



class Subsession(BaseSubsession):
    def creating_session(self):
        for player in self.get_players():
                player.participant.vars['l1']=r.sample(range(101,200),3)## table lottery trattamento 1 (3 numeri)
                player.participant.vars['l1_10']=r.sample(range(101,200),6)## table lottery trattamento 2 (10 numeri)
                player.participant.vars['l2']=[]   #vettore per le 101 porte


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    #domande di controllo
    q1 = models.IntegerField(
            choices=[[1, 'Earth'], [2, 'World'], [3, 'Planet'], [4, 'Globe']],
            )
    q2 = models.IntegerField(
        choices=[[1, 'Orange'], [2, 'Pineapple'], [3, 'Apple'], [4, 'Lemon']],
        )
    q3 = models.IntegerField()

    q4 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        )

    # contatore errori
    errors = models.IntegerField(initial=0)
    r1 =models.IntegerField(initial=0)  # numeri prima lotteria
    r2 =models.IntegerField(initial=0)
    r3 =models.IntegerField(initial=0)
    r4 =models.IntegerField(initial=0)  # numeri prima lotteria
    r5 =models.IntegerField(initial=0)
    r6 =models.IntegerField(initial=0)
    r7 =models.IntegerField(initial=0)  # numeri prima lotteria
    r8 =models.IntegerField(initial=0)
    r9 =models.IntegerField(initial=0)
    r10 =models.IntegerField(initial=0)

    d1 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d2 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d3 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d4 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d5 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d6 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    d7 =models.IntegerField(initial=0)# numeri seconda lotteria (porte)
    p1 =models.IntegerField(initial=0)

    choice1 =models.IntegerField(initial=0)  #scelta prima lotteria
    choice2 = models.IntegerField(initial=0) # scelta seconda lotteria 0 non estrae
    payoff_1 = models.IntegerField(initial=0) # payoff in punti
    money_1 = models.FloatField(initial=0) # payoff in £

    # Bret

    bomb = models.IntegerField(initial=0)
    bomb_location = models.TextField(initial="0")
    boxes_collected = models.IntegerField(initial=0)
    boxes_scheme = models.TextField(initial=0)
    round_to_pay = models.IntegerField(initial=0)
    round_result = models.FloatField(initial=0)
    pay_bret = models.FloatField(initial=0)

    payoff_tot = models.FloatField(initial=0) # payoff in punti
    money_tot = models.FloatField(initial=0) # payoff in £

    def estrai_1 (self):
        if self.session.config['treatment'] == 1:
            self.r1=self.participant.vars['l1'][0]
            self.r2=self.participant.vars['l1'][1]
            self.r3=self.participant.vars['l1'][2]

            print("prima", self.r1, self.r2,self.r3)
        elif self.session.config['treatment'] == 2:
            self.r1=self.participant.vars['l1_10'][0]
            self.r2=self.participant.vars['l1_10'][1]
            self.r3=self.participant.vars['l1_10'][2]
            self.r4=self.participant.vars['l1_10'][3]
            self.r5=self.participant.vars['l1_10'][4]
            self.r6=self.participant.vars['l1_10'][5]


            print("prima", self.r1, self.r2,self.r3, self.r4, self.r5,self.r6)
    def estrai_2 (self):
        #numero porta da aprire
        for i in range (50):
            self.participant.vars['l2'].append(self.choice1-(50-i) ) # numeri da choice1 a choice1-50

        self.participant.vars['l2'].append(self.choice1)   #choice#1

        for i in range (50):
            self.participant.vars['l2'].append(self.choice1+(50+i)) # numeri da choice1 a choice1+50
        # self.participant.vars['l2']=r.sample(range(self.choice1-50,self.choice1+3),50) # estrae il numero
        self.p1=self.participant.vars['l2'][r.randint(0,100)]

        # #numeri dietro le porte
        # self.d1=self.choice1-3
        # self.d2=self.choice1-2
        # self.d3=self.choice1-1
        # self.d4=self.choice1
        # self.d5=self.choice1+1
        # self.d6=self.choice1+2
        # self.d7=self.choice1+3
        print (self.participant.vars['l2'], self.p1)
        # print("p1", self.p1, "porte", self.d1, self.d2,self.d3,self.d4,self.d5,self.d6,self.d7)

    def calcola_payoff (self):
        if self.choice2 == 0:
            self.payoff_1 = self.choice1
        else:
            self.payoff_1 = self.choice2

        self.money_1 = self.payoff_1*Constants.ex

    def set_payoff_total(self):
        if self.bomb == 0:
            self.round_result = self.boxes_collected * Constants.box_value
        else:
            self.round_result = 0
        self.pay_bret = self.round_result
        self.payoff_tot = self.pay_bret  + self.payoff_1
        self.money_tot = self.pay_bret*Constants.ex + self.money_1
