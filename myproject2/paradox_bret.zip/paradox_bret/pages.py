from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants

import json
from otree.api import safe_json

class Instructions(Page):
    form_model = 'player'
    form_fields = ['q1', 'q2', 'q3', 'q4']

    def is_displayed(self):
	       return self.player.errors <= 1

    def error_message(self, values):

        if self.session.config['treatment'] == 1:
                if values['q1'] != 2 and values['q2'] != 3 and values['q3'] != 3 and values['q4'] !=1: #tutte sbagliate
                    self.player.errors += 1
                    return 'All the answers are wrong'

                if values['q1'] != 2 and values['q2'] == 3 and values['q3'] == 3 and values['q4'] ==1: # solo la prima sbagliata
                    self.player.errors += 1
                    return 'The answer to question 1 is wrong'

                if values['q1'] == 2 and values['q2'] != 3 and values['q3'] == 3 and values['q4'] ==1: #solo la seconda sbagliata
                    self.player.errors += 1
                    return 'The answer to question 2 is wrong'

                if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] != 3 and values['q4'] ==1: # solo la terza sbagliata
                    self.player.errors += 1
                    return 'The answer to question 3 is wrong'

                if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] == 3 and values['q4'] !=1: # solo la quarta sbagliata
                    self.player.errors += 1
                    return 'The answer to question 4 is wrong'


                if values['q1'] != 2 and values['q2'] != 3 and  values['q3'] == 3 and values['q4'] ==1: # prima e seconda  sbagliate
                    self.player.errors += 1
                    return 'The answers to question 1 and 2 are wrong'

                if values['q1'] != 2 and values['q2'] == 3 and values['q3'] != 3 and values['q4'] ==1: # prima e terza  sbagliate
                    self.player.errors += 1
                    return 'The answers to question 1 and 3 are wrong'

                if values['q1'] != 2 and values['q2'] == 3 and values['q3'] == 3 and values['q4'] !=1: # prima e quarta  sbagliate
                    self.player.errors += 1
                    return 'The answers to question 1 and 4 are wrong'


                if values['q1'] == 2 and values['q2'] != 3 and  values['q3'] != 3 and values['q4'] ==1:  # seconda  e terza  sbagliate
                    self.player.errors += 1
                    return 'The answers to question 2 and 3 are wrong'

                if values['q1'] == 2 and values['q2'] != 3 and  values['q3'] == 3  and values['q4'] !=1: # seconda  e quarta sbagliate
                    self.player.errors += 1
                    return 'The answers to question 2 and 4 are wrong'


                if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] != 3  and values['q4'] !=1: # terza   e quarta sbagliate
                    self.player.errors += 1
                    return 'The answers to question 3 and 4 are wrong'

        elif self.session.config['treatment'] == 2:
            if values['q1'] != 2 and values['q2'] != 3 and values['q3'] != 6 and values['q4'] !=1: #tutte sbagliate
                self.player.errors += 1
                return 'All the answers are wrong'

            if values['q1'] != 2 and values['q2'] == 3 and values['q3'] == 6 and values['q4'] ==1: # solo la prima sbagliata
                self.player.errors += 1
                return 'The answer to question 1 is wrong'

            if values['q1'] == 2 and values['q2'] != 3 and values['q3'] == 6 and values['q4'] ==1: #solo la seconda sbagliata
                self.player.errors += 1
                return 'The answer to question 2 is wrong'

            if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] != 6 and values['q4'] ==1: # solo la terza sbagliata
                self.player.errors += 1
                return 'The answer to question 3 is wrong'

            if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] == 6 and values['q4'] !=1: # solo la quarta sbagliata
                self.player.errors += 1
                return 'The answer to question 4 is wrong'


            if values['q1'] != 2 and values['q2'] != 3 and  values['q3'] == 6 and values['q4'] ==1: # prima e seconda  sbagliate
                self.player.errors += 1
                return 'The answers to question 1 and 2 are wrong'

            if values['q1'] != 2 and values['q2'] == 3 and values['q3'] != 6 and values['q4'] ==1: # prima e terza  sbagliate
                self.player.errors += 1
                return 'The answers to question 1 and 3 are wrong'

            if values['q1'] != 2 and values['q2'] == 3 and values['q3'] == 6 and values['q4'] !=1: # prima e quarta  sbagliate
                self.player.errors += 1
                return 'The answers to question 1 and 4 are wrong'


            if values['q1'] == 2 and values['q2'] != 3 and  values['q3'] != 6 and values['q4'] ==1:  # seconda  e terza  sbagliate
                self.player.errors += 1
                return 'The answers to question 2 and 3 are wrong'

            if values['q1'] == 2 and values['q2'] != 3 and  values['q3'] == 6  and values['q4'] !=1: # seconda  e quarta sbagliate
                self.player.errors += 1
                return 'The answers to question 2 and 4 are wrong'


            if values['q1'] == 2 and values['q2'] == 3 and  values['q3'] != 6  and values['q4'] !=1: # terza   e quarta sbagliate
                self.player.errors += 1
                return 'The answers to question 3 and 4 are wrong'

    def vars_for_template(self):
            self.player.estrai_1()

            return{
                'errors' : self.player.errors,
                't': self.session.config['treatment'],#trattamento

                }


class Table(Page):
    form_model = 'player'
    form_fields = ['choice1']

    def is_displayed(self):
            return self.player.errors <= 1

    def js_vars(self):
        return dict(
         r1=self.player.r1,
         r2=self.player.r2,
         r3=self.player.r3,
         r4=self.player.r4,
         r5=self.player.r5,
         r6=self.player.r6,
         t= self.session.config['treatment'],#trattamento

         )
    def vars_for_template(self):

        return{
         't':self.session.config['treatment'],
         'r1': self.player.r1,
         'r2': self.player.r2,
         'r3': self.player.r3,
         'r4': self.player.r4,
         'r5': self.player.r5,
         'r6': self.player.r6,


          }
    def before_next_page(self):
       self.player.estrai_2()


class Choice_2(Page):
    form_model = 'player'
    form_fields = ['choice2']

    def is_displayed(self):
            return self.player.errors <= 1

    def js_vars(self):
        return dict(
         p1=self.player.p1,
         l2=self.participant.vars['l2'],
         # d1=self.player.d1,
         # d2=self.player.d2,
         # d3=self.player.d3,
         # d4=self.player.d4,
         # d5=self.player.d5,
         # d6=self.player.d6,
         # d7=self.player.d7,
         choice1=self.player.choice1,

        )

    def vars_for_template(self):
        return{
        'choice1': self.player.choice1,
        'l2': self.participant.vars['l2'],
        'min': self.player.choice1-50,
        'max': self.player.choice1+50,
        # 'd1': self.player.d1,
        # 'd2': self.player.d2,
        # 'd3': self.player.d3,
        # 'd4': self.player.d4,
        # 'd5': self.player.d5,
        # 'd6': self.player.d6,
        # 'd7': self.player.d7,
                }

    def before_next_page(self):
        self.player.calcola_payoff()
        self.player.set_payoff_total()



class Results(Page):

    def is_displayed(self):
            return self.player.errors <= 1

    def vars_for_template(self):
        return{
            'payoff_1': self.player.payoff_1,
            'money_1': self.player.money_1,
            'show_up': Constants.show_up,
            'player_in_all_rounds':   self.player.in_all_rounds(),
            'box_value':              Constants.box_value,
            'boxes_total':            Constants.num_rows * Constants.num_cols,
            'boxes_collected':        self.player.boxes_collected,
            'bomb':                   self.player.bomb,
            'round_result':           self.player.round_result,
            'payoff_tot':           self.player.payoff_tot ,
            'money_tot':            self.player.money_tot ,
             }






class Stop(Page):
    def is_displayed(self):
            return self.player.errors > 1



class InstructionsBret(Page):

	# only display instruction in round 1
	def is_displayed(self):
		return self.player.errors <= 1

	# variables for use in template
	def vars_for_template(self):
		return {
			'num_rows':             Constants.num_rows,
			'num_cols':             Constants.num_cols,
			'num_boxes':            Constants.num_rows * Constants.num_cols,
			'num_nobomb':           Constants.num_rows * Constants.num_cols - 1,
			'box_value':            Constants.box_value,
			'time_interval':        Constants.time_interval,
		}


class Bret(Page):

	# form fields on player level
	form_model = 'player'
	form_fields = [
		'bomb',
		'boxes_collected',
		'boxes_scheme',
		'bomb_location',
	]

	def is_displayed(self):
		return self.player.errors <= 1

	# set payoffs and globals
	def before_next_page(self):

		self.session.vars['reset'] = True
		self.player.set_payoff_total()


	# jsonify BRET settings for Javascript application
	def vars_for_template(self):
		reset = self.session.vars.get('reset',False)
		if reset == True:
		   del self.session.vars['reset']

		input = not Constants.devils_game if not Constants.dynamic else False

		return {
			'reset': safe_json(reset),
			'input': safe_json(input),
			'random': safe_json(Constants.random),
			'dynamic': safe_json(Constants.dynamic),
			'num_rows': safe_json(Constants.num_rows),
			'num_cols': safe_json(Constants.num_cols),
			'feedback': safe_json(Constants.feedback),
			'undoable': safe_json(Constants.undoable),
			'box_width': safe_json(Constants.box_width),
			'box_height':safe_json(Constants.box_height),
			'time_interval': safe_json(Constants.time_interval),
		}



class Back_to_Prolific(Page):
    def is_displayed(self):
            return self.player.errors <= 1

# class ResultsBret(Page):
#
# 	# only display results after all rounds have been played
#     def is_displayed(self):
#         return self.player.errors <= 1
#
# 	# variables for use in template
#     def vars_for_template(self):
#         try:
#             bomb_row = self.player.bomb_location.split(',')[0]
#             bomb_row = bomb_row.replace('{"row":','')
#             bomb_col = self.player.bomb_location.split(',')[1]
#             bomb_col = bomb_col.replace('"col":','')
#             bomb_col = bomb_col.replace('}','')
#         except:
#             bomb_row = 1
#             bomb_col = 1
#
#
#
#         return {
#             'player_in_all_rounds':   self.player.in_all_rounds(),
#             'box_value':              Constants.box_value,
#             'boxes_total':            Constants.num_rows * Constants.num_cols,
#             'boxes_collected':        self.player.boxes_collected,
#             'bomb':                   self.player.bomb,
#             'bomb_row':               bomb_row,
#             'bomb_col':               bomb_col,
#             'round_result':           self.player.round_result,
#             'payoff_tot':           self.player.payoff_tot ,
#             'money_tot':            self.player.money_tot ,
# 		          }








page_sequence = [
Instructions,
# Stop,
InstructionsBret,
Bret,
Table,
Choice_2,
Results,
Back_to_Prolific,

]
