from random import randrange
from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)



author = 'Your name here'

ddoc = """
SIF versione Prolif - finanziatore"""
# #1 "F fixed" (finanziatore con pagamento fisso) 2 Quantity 3 "Quality" 4 "Average Quantity" 5 "Threshold"

class Constants(BaseConstants):
    name_in_url = 'sif_F'
    players_per_group = None
    endowment_F=60
    num_rounds = 1
    B_return_1= 0.1 #pagamento beni 1 per il beneficiario
    B_return_2 = 1 #pagamento beni 2 per il beneficiario
  #  L_list=[1,2,3,4,5]  #lista beni di tipo 2 prodotti dai lavoratori
  #  L_codes=['1', '2','3','4','5'] #codici lavoratori


class Subsession(BaseSubsession):

    def creating_session(self):
        self.session.config['real_world_currency_per_point'] = 0.10
        self.session.config['participation_fee'] = 0.50

        # settings.REAL_WORLD_CURRENCY_CODE = 'GBP'
        # settings.LANGUAGE_CODE = 'en'
        # settings.USE_POINTS = True
        # #self.vettore=self.session.config['vector'].split
        # # self.session.vars['L_list']=[1,2,5,4,5]
        self.session.vars['L_code']=self.session.config['L_code'].split()
        self.session.vars['L_list']=self.session.config['L_list'].split()



class Group(BaseGroup):
    pass


class Player(BasePlayer):

    #questionario
   Errors=models.IntegerField(initial=0)  #errori nelle domande di controllo.
   q1 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)
   q2 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)

   q3 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)
   q4 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)

   q5 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)


   q6 = models.IntegerField(
        choices=[[1, 'True'], [2, 'False']],
        widget=widgets.RadioSelect)


   q7 = models.IntegerField(
        choices=[[1, 'COST'], [2, 'EARNING']],
         )

   q8 = models.IntegerField(

         )



  # Prol= models.StringField(label=False) #prolific ID
    # controls and beliefs
   F_debrief=models.StringField()
   F_pay= models.FloatField(initial=0)
    #beni di tipo 2 prodotti dai lavoratori
   L1 = models.IntegerField(initial=-99)
   L2 = models.IntegerField(initial=-99)
   L3 = models.IntegerField(initial=-99)
   L4 = models.IntegerField(initial=-99)
   L5 = models.IntegerField(initial=-99)
   L_av=models.FloatField(initial=-99)

     #beni di tipo 2 prodotti dai lavoratori
   L1_code = models.StringField(initial=-99)
   L2_code = models.StringField(initial=-99)
   L3_code = models.StringField(initial=-99)
   L4_code = models.StringField(initial=-99)
   L5_code = models.StringField(initial=-99)

    #ricavi per L
   L1_R = models.IntegerField(initial=-99)
   L2_R = models.IntegerField(initial=-99)
   L3_R = models.IntegerField(initial=-99)
   L4_R = models.IntegerField(initial=-99)
   L5_R = models.IntegerField(initial=-99)
   L_R_av=models.FloatField(initial=-99)

    #benefici per B
   B1 = models.FloatField(initial=-99)
   B2 = models.FloatField(initial=-99)
   B3 = models.FloatField(initial=-99)
   B4 = models.FloatField(initial=-99)
   B5 = models.FloatField(initial=-99)
   B_av=models.FloatField(initial=-99)

    #scelte di F
   L1_choice = models.IntegerField(
        choices=[[1, 'Finance'], [0, 'Do not Finance']]
            )
   L2_choice = models.IntegerField(
        choices=[[1, 'Finance'], [0, 'Do not Finance']],
           )
   L3_choice = models.IntegerField(
        choices=[[1, 'Finance'], [0, 'Do not Finance']],

        )
   L4_choice = models.IntegerField(
        choices=[[1, 'Finance'], [0, 'Do not Finance']],

        )
   L5_choice = models.IntegerField(

        choices=[[1, 'Finance'], [0, 'Do not Finance']],
        )

   L_choice = models.IntegerField(
          choices=[[1, 'Finance'], [0, 'Do not Finance']],

         )  # trattamento 4 media

    #valutazioni di F
   L1_ass = models.IntegerField(
         choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )
   L2_ass = models.IntegerField(
        choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )
   L3_ass = models.IntegerField(
         choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )
   L4_ass = models.IntegerField(
         choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )
   L5_ass = models.IntegerField(
         choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )
   L_ass = models.IntegerField(
         choices=[[0, '0 Not at all'], [1,'1'], [2,'2'], [3,'3'],[4,'4'], [5, '5 Completely']],

         )  # trattamento 4 media

    # payoff L

   L1_pay =  models.IntegerField()
   L2_pay =  models.IntegerField()
   L3_pay =  models.IntegerField()
   L4_pay =  models.IntegerField()
   L5_pay =  models.IntegerField()

   L1_pay_pound =  models.FloatField()
   L2_pay_pound =  models.FloatField()
   L3_pay_pound =  models.FloatField()
   L4_pay_pound =  models.FloatField()
   L5_pay_pound =  models.FloatField()

#payoff che il finanziatore ottiene da ciascun lavoratore
   F_L1_pay =  models.FloatField()
   F_L2_pay =  models.FloatField()
   F_L3_pay =  models.FloatField()
   F_L4_pay =  models.FloatField()
   F_L5_pay =  models.FloatField()

# vettori



   def leggi_dati(self):


        # self.L1=Constants.L_list[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-4]
        # self.L2=Constants.L_list[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-3]
        # self.L3=Constants.L_list[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-2]
        # self.L4=Constants.L_list[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-1]
        # self.L5=Constants.L_list[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)]

        self.L1=int(self.session.vars['L_list'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-4])
        self.L2=int(self.session.vars['L_list'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-3])
        self.L3=int(self.session.vars['L_list'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-2])
        self.L4=int(self.session.vars['L_list'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-1])
        self.L5=int(self.session.vars['L_list'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)])

        self.L_av=(self.L1+self.L2+self.L3+self.L4+self.L5)/5 # media

        print(self.L1,self.L2,self.L3,self.L4)

        self.L1_choice=-1
        self.L2_choice=-1
        self.L3_choice=-1
        self.L4_choice=-1
        self.L5_choice=-1

        self.L1_ass=-1
        self.L2_ass=-1
        self.L3_ass=-1
        self.L4_ass=-1
        self.L5_ass=-1


        # self.L1_code=Constants.L_codes[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-4]
        # self.L2_code=Constants.L_codes[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-3]
        # self.L3_code=Constants.L_codes[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-2]
        # self.L4_code=Constants.L_codes[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-1]
        # self.L5_code=Constants.L_codes[(4*self.participant.id_in_session)+(self.participant.id_in_session-1)]

        self.L1_code=self.session.vars['L_code'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-4]
        self.L2_code=self.session.vars['L_code'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-3]
        self.L3_code=self.session.vars['L_code'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-2]
        self.L4_code=self.session.vars['L_code'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)-1]
        self.L5_code=self.session.vars['L_code'][(4*self.participant.id_in_session)+(self.participant.id_in_session-1)]

        self.L1_R=20-self.L1
        self.L2_R=20-self.L2
        self.L3_R=20-self.L3
        self.L4_R=20-self.L4
        self.L5_R=20-self.L5

        self.L_R_av=(self.L1_R+self.L2_R+self.L3_R+self.L4_R+self.L5_R)/5 # media


        self.B1=self.L1+(20-2*self.L1)*Constants.B_return_1
        self.B2=self.L2+(20-2*self.L2)*Constants.B_return_1
        self.B3=self.L3+(20-2*self.L3)*Constants.B_return_1
        self.B4=self.L4+(20-2*self.L4)*Constants.B_return_1
        self.B5=self.L5+(20-2*self.L5)*Constants.B_return_1

        self.B_av=(self.B1+self.B2+self.B3+self.B4+self.B5)/5 # media


   def set_payoff(self):


      if self.session.config['treatment'] != 4:
       #payoff lavoratore
           if self.L1_choice == 0:
              self.L1_pay =  self.L1_R
           else:
              self.L1_pay =  self.L1_R+10

           if self.L2_choice == 0:
              self.L2_pay =  self.L2_R
           else:
              self.L2_pay =  self.L2_R+10

           if self.L3_choice == 0:
              self.L3_pay =  self.L3_R
           else:
              self.L3_pay =  self.L3_R+10

           if self.L4_choice == 0:
              self.L4_pay =  self.L4_R
           else:
              self.L4_pay =  self.L4_R+10

           if self.L5_choice == 0:
              self.L5_pay =  self.L5_R
           else:
              self.L5_pay =  self.L5_R+10

        ## payoff finanziatore

            # baseline

           if self.session.config['treatment'] == 5:
                if self.L1_choice == 0:
                   self.F_L1_pay =  12
                else:
                    if self.L1 < 3:
                        self.F_L1_pay =  5.6
                    else:
                        self.F_L1_pay =  14.4

                if self.L2_choice == 0:
                        self.F_L2_pay =  12
                else:

                    if self.L2 < 3:
                         self.F_L2_pay =  5.6
                    else:
                         self.F_L2_pay =  14.4

                if self.L3_choice == 0:
                        self.F_L3_pay =  12
                else:
                    if self.L3 < 3:
                         self.F_L3_pay =  5.6
                    else:
                         self.F_L3_pay =  14.4

                if self.L4_choice == 0:
                    self.F_L4_pay =  12
                else:

                    if self.L4 < 3:
                         self.F_L4_pay =  5.6
                    else:
                         self.F_L4_pay =  14.4

                if self.L5_choice == 0:
                    self.F_L5_pay =  12
                else:
                    if self.L5 < 3:
                         self.F_L5_pay =  5.6
                    else:
                         self.F_L5_pay =  14.4


                self.payoff=self.F_L1_pay+self.F_L2_pay+self.F_L3_pay+self.F_L4_pay+self.F_L5_pay


           elif self.session.config['treatment'] == 1:
               self.payoff=Constants.endowment_F



            # T2 quantity

           elif self.session.config['treatment'] == 2:
                if self.L1_choice == 0:
                    self.F_L1_pay =  12
                else:
                    self.F_L1_pay = self.L1+(20-2*self.L1)*0.8

                if self.L2_choice == 0:
                    self.F_L2_pay =  12
                else:
                    self.F_L2_pay = self.L2+(20-2*self.L2)*0.8

                if self.L3_choice == 0:
                    self.F_L3_pay =  12
                else:
                    self.F_L3_pay = self.L3+(20-2*self.L3)*0.8


                if self.L4_choice == 0:
                    self.F_L4_pay =  12
                else:
                    self.F_L4_pay = self.L4+(20-2*self.L4)*0.8


                if self.L5_choice == 0:
                    self.F_L5_pay =  12
                else:
                    self.F_L5_pay = self.L5+(20-2*self.L5)*0.8

                self.payoff=self.F_L1_pay+self.F_L2_pay+self.F_L3_pay+self.F_L4_pay+self.F_L5_pay

            # T3 quality

           else:
                if self.L1_choice == 0:
                    self.F_L1_pay =  12
                else:
                    self.F_L1_pay = self.B1*2

                if self.L2_choice == 0:
                    self.F_L2_pay =  12
                else:
                    self.F_L2_pay = self.B2*2

                if self.L3_choice == 0:
                    self.F_L3_pay =  12
                else:
                    self.F_L3_pay = self.B3*2


                if self.L4_choice == 0:
                    self.F_L4_pay =  12
                else:
                    self.F_L4_pay = self.B4*2


                if self.L5_choice == 0:
                    self.F_L5_pay =  12
                else:
                    self.F_L5_pay = self.B5*2

                self.payoff=self.F_L1_pay+self.F_L2_pay+self.F_L3_pay+self.F_L4_pay+self.F_L5_pay

                self.L1_pay_pound =  self.L1_pay*0.10
                self.L2_pay_pound =  self.L2_pay*0.10
                self.L3_pay_pound =  self.L3_pay*0.10
                self.L4_pay_pound =  self.L4_pay*0.10
                self.L5_pay_pound =  self.L5_pay*0.10
            #trattamento 4
      else:
              if self.L_choice==0: # non finanzia
                 self.payoff=60
              else:
                 self.payoff=self.B_av*2*5
