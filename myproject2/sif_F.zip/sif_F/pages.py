from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants

# class ProlificID(Page):
#    form_model = 'player'
#    form_fields = ['Prol']


class Stop(Page):
  def is_displayed(self):
          return self.player.Errors > 2

#domande di controllo

class Instructions_1(Page):
    def vars_for_template(self):
        return{
        'treatment': self.session.config['treatment']
        }

#domande di controllo

class Instructions_2(Page):

    form_model = 'player'
    form_fields = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6','q7']

    def is_displayed(self):
            return self.session.config['treatment']!=4

    def error_message(self, values):
        if values['q1'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 1 is wrong'
        #attention check
        if values['q2'] != 2:
            self.player.Errors += 1
            return 'The answer to question n. 2 is wrong'

        if values['q3'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 3 is wrong'

        if values['q4'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 4 is wrong'
        #attention check
        if values['q5'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 5 is wrong'

        if self.session.config['treatment'] == 1:
           if values['q6'] != 1:
               self.player.Errors += 1
               return 'The answer to question n. 6 is wrong'
        else:
            if values['q6'] != 2:
               self.player.Errors += 1
               return 'The answer to question n. 6 is wrong'

        if values['q7'] != 2:
            self.player.Errors += 1
            return 'The answer to question n. 7 is wrong'


    def vars_for_template(self):
        return{
        'treatment': self.session.config['treatment']
        }

class Instructions_2_treat_4(Page):

    form_model = 'player'
    form_fields = ['q1', 'q2', 'q3', 'q4', 'q5', 'q7','q8']

    def is_displayed(self):
            return self.session.config['treatment']==4

    def error_message(self, values):
        if values['q1'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 1 is wrong'
        #attention check
        if values['q2'] != 2:
            self.player.Errors += 1
            return 'The answer to question n. 2 is wrong'

        if values['q3'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 3 is wrong'

        if values['q4'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 4 is wrong'
        #attention check
        if values['q5'] != 1:
            self.player.Errors += 1
            return 'The answer to question n. 5 is wrong'

        if values['q7'] != 2:
               self.player.Errors += 1
               return 'The answer to question n. 7 is wrong'

            #question 6 in treatment 4
        if values['q8'] != 44:
            self.player.Errors += 1
            return 'The answer to question n. 6 is wrong'


    def vars_for_template(self):
        return{
        'treatment': self.session.config['treatment']
        }




## scelte L
class  choice_F (Page):
        form_model = 'player'
        form_fields = ['L1_choice', 'L2_choice', 'L3_choice','L4_choice','L5_choice' ]


        def is_displayed(self):
            return self.session.config['treatment']!=4 and self.player.Errors <= 2

        def vars_for_template(self):
            self.player.leggi_dati()

            return {
        #beni di tipo 2
            'L1': self.player.L1,
            'L2': self.player.L2,
            'L3': self.player.L3,
            'L4': self.player.L4,
            'L5': self.player.L5,
            'L_av': self.player.L_av,
            #beni di tipo 1
            'L1_1': 20-2*self.player.L1,
            'L2_1': 20-2*self.player.L2,
            'L3_1': 20-2*self.player.L3,
            'L4_1': 20-2* self.player.L4,
            'L5_1': 20-2*self.player.L5,
            'L_1_av':(100-2*(self.player.L_av*5))/5, #beni di tipo 1 trattamento 4

            'L1_R': self.player.L1_R,
            'L2_R': self.player.L2_R,
            'L3_R': self.player.L3_R,
            'L4_R': self.player.L4_R,
            'L5_R': self.player.L5_R,
            'L_R_av': self.player.L_R_av,

            'B1': self.player.B1,
            'B2': self.player.B2,
            'B3': self.player.B3,
            'B4': self.player.B4,
            'B5': self.player.B5,
            'B_av': self.player.B_av,
            'treatment': self.session.config['treatment'],
            #T2 quantity  payoff finanziatore
            'Payoff_T1_F_L1': self.player.L1+(20-2*self.player.L1)*0.8,
            'Payoff_T1_F_L2': self.player.L2+(20-2*self.player.L2)*0.8,
            'Payoff_T1_F_L3': self.player.L3+(20-2*self.player.L3)*0.8,
            'Payoff_T1_F_L4': self.player.L4+(20-2*self.player.L4)*0.8,
            'Payoff_T1_F_L5': self.player.L5+(20-2*self.player.L5)*0.8,
            #T3 quanlity  payoff finanziatore
            'Payoff_T2_F_L1': self.player.B1*2,
            'Payoff_T2_F_L2': self.player.B2*2,
            'Payoff_T2_F_L3': self.player.B3*2,
            'Payoff_T2_F_L4': self.player.B4*2,
            'Payoff_T2_F_L5': self.player.B5*2,
            #T4 quality  payoff finanziatore
            'Payoff_T4_F':self.player.B_av*2,


        }


        def before_next_page(self):

                self.player.set_payoff()



class  choice_F_treat_4 (Page):
        form_model = 'player'
        form_fields = ['L_choice' ]


        def is_displayed(self):
            return self.session.config['treatment'] ==4 and self.player.Errors <=2

        def vars_for_template(self):
            self.player.leggi_dati()

            return {
        #beni di tipo 2

            'L_av': self.player.L_av,
            #beni di tipo 1

            'L_1_av':(100-2*(self.player.L_av*5))/5, #beni di tipo 1 trattamento 4

            'L_R_av': self.player.L_R_av,

            'B_av': self.player.B_av,
            'treatment': self.session.config['treatment'],

            #T4 quality  payoff finanziatore
            'Payoff_T4_F':self.player.B_av*2,


        }


        def before_next_page(self):

                self.player.set_payoff()


class  assessment_F (Page):
        form_model = 'player'
        form_fields = ['L1_ass', 'L2_ass', 'L3_ass','L4_ass','L5_ass']

        def is_displayed(self):
            return self.session.config['treatment'] != 4 and self.player.Errors <= 2

        def vars_for_template(self):

            return {
        #beni di tipo 2
            'L1': self.player.L1,
            'L2': self.player.L2,
            'L3': self.player.L3,
            'L4': self.player.L4,
            'L5': self.player.L5,
            'L_av': self.player.L_av,


            #beni di tipo 1
            'L1_1': 20-2*self.player.L1,
            'L2_1': 20-2*self.player.L2,
            'L3_1': 20-2*self.player.L3,
            'L4_1': 20-2* self.player.L4,
            'L5_1': 20-2*self.player.L5,
            'L_1_av':100-2*(self.player.L_av*5),

            'L1_R': self.player.L1_R,
            'L2_R': self.player.L2_R,
            'L3_R': self.player.L3_R,
            'L4_R': self.player.L4_R,
            'L5_R': self.player.L5_R,
            'L_R_av': self.player.L_R_av,
            'B1': self.player.B1,
            'B2': self.player.B2,
            'B3': self.player.B3,
            'B4': self.player.B4,
            'B5': self.player.B5,
            'B_av': self.player.B_av,

            'L1_choice': self.player.L1_choice,
            'L2_choice': self.player.L2_choice,
            'L3_choice': self.player.L3_choice,
            'L4_choice': self.player.L4_choice,
            'L5_choice': self.player.L5_choice,
            # 'L_choice': self.player.L_choice,
            'treatment': self.session.config['treatment'],

        }



class  assessment_F_treat_4 (Page):
        form_model = 'player'
        form_fields = ['L_ass' ]


        def is_displayed(self):
            return self.session.config['treatment'] ==4 and self.player.Errors <=2

        def vars_for_template(self):

            return {
        #beni di tipo 2

            'L_av': self.player.L_av,


            #beni di tipo 1

            'L_1_av':(100-2*(self.player.L_av*5))/5,


            'L_R_av': self.player.L_R_av,

            'B_av': self.player.B_av,
            'L_choice': self.player.L_choice,

            'treatment': self.session.config['treatment'],

        }


class ResultsWaitPage(WaitPage):
  pass



class Results(Page):

    def is_displayed (self):
        return self.player.Errors <= 2

    def vars_for_template(self):


        return {

        'finalpay': self.participant.payoff,

        'finalmoney': self.participant.payoff_plus_participation_fee(),
        'treatment': self.session.config['treatment'],

        }



class Questionario(Page):
    form_model = 'player'
    def is_displayed (self):
        return self.player.Errors <= 2

    def get_form_fields(self):
        rt = ['F_debrief']
        return rt


class Back_to_Prolific (Page):
    def is_displayed (self):
        return self.player.Errors <= 2


page_sequence = [
 # ProlificID,
  Instructions_1,
  Instructions_2,
  Instructions_2_treat_4,
  Stop,
  choice_F,
  choice_F_treat_4,
  assessment_F,
  assessment_F_treat_4,
  Results,
  Questionario,
  Back_to_Prolific
]
