from otree.api import *
c=Currency
import random

doc = """
Your app description
"""


class C(BaseConstants):
	REAL_WORLD_CURRENCY_CODE = 'EUR'
	NAME_IN_URL = 'faillo_content_spanish_pract_gamma5'
	PLAYERS_PER_GROUP = 4
	NUM_ROUNDS = 2
	CONVERTED_PRICES = [0.07, 0.14,	0.21,0.28,0.35,	0.42,0.49,0.56,	0.63,	0.7]
	ALPHA_1 = 1.5
	ALPHA_2 = 1
	D = 0.3
	GAMMA = 0.5
	MUA = 14
	MUB = 14
	H_NZR = [2.65,2.70,2.7988]
	H_ZR2 = [2.68,2.70,2.8270] # aggiunto
	H_ZR1 = [2.7486,2.80,2.9114] # aggiunto
	C_A = 0.02 # aggiunto
	C_B = 0.02 # aggiunto
	T = [0.29,0.26,0.2375]
	exchange=1/1000


class Subsession(BaseSubsession):
	pass


class Group(BaseGroup):
	pass


class Player(BasePlayer):
	roles = models.StringField(initial="")
	price_content_1 = models.IntegerField(initial=0,min=1,max=10)
	price_content_2 = models.IntegerField(initial=0,min=1,max=10)
	tarif_service_1 = models.IntegerField(initial=0)
	tarif_service_2 = models.IntegerField(initial=0)
	start_service = models.StringField(initial="")
	second_service = models.StringField(initial="")
	id_content_first = models.StringField(initial="")
	id_content_second = models.StringField(initial="")
	id_content = models.StringField(initial ="")
	profit = models.FloatField(initial=0)  #nuovo
	available_content_second = models.StringField(initial="")

	q1A = models.FloatField(initial=0)
	q2A = models.FloatField(initial=0)
	q1B = models.FloatField(initial=0)
	q2B = models.FloatField(initial=0)

	u_A = models.FloatField(initial=0)
	u_B = models.FloatField(initial=0)

	winner = models.IntegerField(initial=0)

#control questions

	q1 = models.IntegerField(
         choices=[[1, 'SI'], [2, 'NO']],
         widget=widgets.RadioSelect)
	q2 = models.IntegerField(
         choices=[[1, 'SI'], [2, 'NO']],
         widget=widgets.RadioSelect)
	q3 = models.IntegerField(
         choices=[[1, 'SI'], [2, 'NO']],
         widget=widgets.RadioSelect)
	q4 = models.IntegerField(
         choices=[[1, 'SI'], [2, 'NO']],
         widget=widgets.RadioSelect)
	errors = models.IntegerField(initial =0)


#############################################################################
# 								Function
#############################################################################
#----------------------------------------------------------------------------
def creating_session(subsession: Subsession):
	session = subsession.session
	# subsession.group_randomly()
	c = random.choice(['service_1','service_2'])
	for p in subsession.get_players():
		if p.id_in_group < 3:
			p.roles = 'service_' + str(p.id_in_group)
		else:
			p.roles = 'content_' + str(p.id_in_group - 2)

		p.start_service = c
		if p.start_service == 'service_1':
			p.second_service = 'service_2'
		else:
			p.second_service = 'service_1'

		p.participant.vars['cum_payoff'] = 0
		p.participant.vars['history'] = ""


def get_demand(group: Group):
	for p in group.get_players():
		if p.roles == 'service_1':
			p_sp1 = p
		elif p.roles == 'service_2':
			p_sp2 = p
		elif p.roles == 'content_1':
			p_cp1 = p
		else :
			p_cp2 = p


	cp1_price = C.CONVERTED_PRICES[p_cp1.price_content_1 - 1]
	cp2_price = C.CONVERTED_PRICES[p_cp2.price_content_2 - 1]

	if p_sp1.id_content == 'nobody' and p_sp2.id_content == 'nobody':
		teta = [0.29,0.26,0.2375]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		print("tauspa", teta[p_sp1.tarif_service_1 - 1])
	elif p_sp1.id_content == 'content_1' and p_sp2.id_content == 'nobody':
		teta = [0.1526,0.09,0.02]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price - teta[p_sp1.tarif_service_1 - 1]) - ( 1- C.GAMMA ) * C.D   )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1]  )
		teta = [0.29,0.26,0.2375]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )


	elif p_sp1.id_content == 'content_2' and p_sp2.id_content == 'nobody':
		teta = [0.35,0.26,0.2785]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1- C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1])
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price - teta[p_sp1.tarif_service_1 - 1])  - ( 1- C.GAMMA ) * C.D   )
		teta = [0.29,0.26,0.2375]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp2.tarif_service_2 - 1] + C.D) )


	elif p_sp1.id_content == 'nobody' and p_sp2.id_content == 'content_1':
		teta = [0.29,0.26,0.2375]

		print("***************",cp1_price,cp2_price,p_sp1.tarif_service_1 - 1,p_sp1.tarif_service_2 - 1,teta[p_sp1.tarif_service_1 - 1])
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D)  )
		teta = [0.1526,0.09,0.02]
		print("------------",cp1_price,cp2_price,p_sp1.tarif_service_1 - 1,p_sp1.tarif_service_2 - 1,teta[p_sp2.tarif_service_2 - 1])
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	elif p_sp1.id_content == 'nobody' and p_sp2.id_content == 'content_2':
		teta = [0.29,0.26,0.2375]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * (teta[p_sp1.tarif_service_1 - 1] + C.D) )
		teta = [0.35,0.26,0.2785]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )


	elif p_sp1.id_content == 'content_1' and p_sp2.id_content == 'content_2':
		teta = [0.1526,0.09,0.02]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price - teta[p_sp1.tarif_service_1 - 1]) - ( 1- C.GAMMA ) * C.D   )
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * C.D - teta[p_sp1.tarif_service_1 - 1]  )
		teta = [0.35,0.26,0.2785]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	elif p_sp1.id_content == 'content_2' and p_sp2.id_content == 'content_1':
		teta = [0.35,0.26,0.2785]
		q1A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1- C.GAMMA ) * C.D   - teta[p_sp1.tarif_service_1 - 1])
		q2A = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price - teta[p_sp1.tarif_service_1 - 1])  - ( 1- C.GAMMA ) * C.D   )
		teta = [0.1526,0.09,0.02]
		q1B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_1 - cp1_price - C.GAMMA * ( C.ALPHA_2 - cp2_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )
		q2B = ( 1 / (1 - C.GAMMA**2) ) * ( C.ALPHA_2 - cp2_price - C.GAMMA * ( C.ALPHA_1 - cp1_price ) - ( 1 - C.GAMMA ) * ( teta[p_sp2.tarif_service_2 - 1] + C.D ) )

	if q1A < 0:
		q1A = 0
	if q2A < 0:
		q2A = 0
	if q1B < 0:
		q1B = 0
	if q2B < 0:
		q2B = 0

	for p in group.get_players():
		p.q1A = q1A
		p.q2A = q2A
		p.q1B = q1B
		p.q2B = q2B
	print('DEMAND:',q1A,q2A,q1B,q2B)

	# CALCOLO UTILITA SP1 (A)
	if p_sp1.id_content == 'content_1':
		teta2 = [0.1526,0.09,0.02]
		teta1 = [0,0,0]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_ZR1[p_sp1.tarif_service_1 - 1] + ( teta1[p_sp1.tarif_service_1 - 1] * q1A + teta2[p_sp1.tarif_service_1 - 1] * q2A )  )
	elif p_sp1.id_content == 'content_2':
		teta1 = [0.35,0.26,0.2785]
		teta2 = [0,0,0]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_ZR2[p_sp1.tarif_service_1 - 1] + ( teta1[p_sp1.tarif_service_1 - 1] * q1A + teta2[p_sp1.tarif_service_1 - 1] * q2A )  )
	else: #nzr
		teta = [0.29,0.26,0.2375]
		u_2_A = cp1_price * q1A + cp2_price * q2A + ( C.H_NZR[p_sp1.tarif_service_1 - 1] + ( teta[p_sp1.tarif_service_1 - 1] * q1A + teta[p_sp1.tarif_service_1 - 1] * q2A )  )

	u_1_A =  C.ALPHA_1 * q1A -  1/2 * (q1A**2) + C.ALPHA_2 * q2A - 1/2 * (q2A**2) - C.GAMMA * q1A * q2A
	u_3_A = ( C.D *(C.MUA - (q1A + q2A) ) )

	u_A = u_1_A - u_2_A + u_3_A
	print ("u1a", u_1_A, "u2a",u_2_A, "u3a",u_3_A)
	# CALCOLO UTILITA SP2 (B)
	if p_sp2.id_content == 'content_1':
		teta2 = [0.1526,0.09,0.02]
		teta1 = [0,0,0]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_ZR1[p_sp2.tarif_service_2 - 1] + ( teta1[p_sp2.tarif_service_2 - 1] * q1B + teta2[p_sp2.tarif_service_2 - 1] * q2B )  )
	elif p_sp2.id_content == 'content_2':
		teta1 = [0.35,0.26,0.2785]
		teta2 = [0,0,0]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_ZR2[p_sp2.tarif_service_2 - 1] + ( teta1[p_sp2.tarif_service_2 - 1] * q1B + teta2[p_sp2.tarif_service_2 - 1] * q2B )  )
	else:
		teta = [0.29,0.26,0.2375]
		u_2_B = cp1_price * q1B + cp2_price * q2B + ( C.H_NZR[p_sp2.tarif_service_2 - 1] + ( teta[p_sp2.tarif_service_2 - 1] * q1B + teta[p_sp2.tarif_service_2 - 1] * q2B )  )

	u_1_B =  C.ALPHA_1 * q1B -  1/2 * (q1B**2) + C.ALPHA_2 * q2B - 1/2 * (q2B**2) - C.GAMMA * q1B * q2B
	u_3_B = ( C.D * (C.MUB - (q1B + q2B) ) )

	u_B = u_1_B - u_2_B + u_3_B
	print ("u1b", u_1_B, "u2b",u_2_B, "u3b",u_3_B)


	# winner
	if u_A > u_B:
		win = 1
	elif u_A == u_B:
		win = random.randint(1,2)
	else:
		win = 2

	for p in group.get_players():
		p.u_A = u_A
		p.u_B = u_B
		p.winner = win
		set_payoff(p)





def set_payoff(player: Player):
	H_TARIF = [15,25,38]
	T = [1,0.5,0.25]

#CP
	if player.roles == 'content_1':
			cp1_price = C.CONVERTED_PRICES[player.price_content_1 - 1]
			player.profit = 2800*(player.q1A*cp1_price + player.q1B*cp1_price) - 100

	elif player.roles == 'content_2':
			cp2_price = C.CONVERTED_PRICES[player.price_content_2 - 1]
			player.profit = (player.q2A*cp2_price + player.q2B*cp2_price)*1000

#ISP
	else:
		if player.roles == 'service_1' and player.winner == 1:
			if player.id_content == 'nobody':
				teta=[0.29,0.26,0.2375]
				player.profit= 10000*(C.H_NZR[player.tarif_service_1 - 1] + teta[player.tarif_service_1 - 1]*player.q1A + teta[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5000
			elif player.id_content == 'content_1':
				teta2 = [0.1526,0.09,0.02]
				teta1 = [0,0,0]
				player.profit= 10000*(C.H_ZR1[player.tarif_service_1 - 1] + teta1[player.tarif_service_1 - 1]*player.q1A + teta2[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5000
			elif player.id_content == 'content_2':
				teta1 = [0.35,0.26,0.2785]
				teta2 = [0,0,0]
				player.profit= 10000*(C.H_ZR2[player.tarif_service_1 - 1] + teta1[player.tarif_service_1 - 1]*player.q1A + teta2[player.tarif_service_1 - 1]*player.q2A  -C.C_A*(C.MUA+(C.MUA**2)/2))-5000
		elif player.roles == 'service_1' and player.winner == 2:
				player.profit = 0
		elif player.roles == 'service_2' and player.winner ==2:
			if player.id_content == 'nobody':
				teta=[0.29,0.26,0.2375]
				player.profit= 10000*(C.H_NZR[player.tarif_service_2 - 1] + teta[player.tarif_service_2 - 1]*player.q1B + teta[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5000
			elif player.id_content == 'content_1':
				teta2 = [0.1526,0.09,0.02]
				teta1 = [0,0,0]
				player.profit= 10000*(C.H_ZR1[player.tarif_service_2 - 1] + teta1[player.tarif_service_2 - 1]*player.q1B + teta2[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5000
			elif player.id_content == 'content_2':
				teta1 = [0.35,0.26,0.2785]
				teta2 = [0,0,0]
				player.profit= 10000*(C.H_ZR2[player.tarif_service_2 - 1] + teta1[player.tarif_service_2 - 1]*player.q1B + teta2[player.tarif_service_2 - 1]*player.q2B  -C.C_B*(C.MUB+(C.MUB**2)/2))-5000
		elif player.roles == 'service_2' and player.winner == 1:
				player.profit = 0


	player.participant.vars['cum_payoff'] = player.participant.vars['cum_payoff'] + player.profit
	player.payoff=format(float(player.profit*C.exchange))
#############################################################################
# 								Pages
#############################################################################
#----------------------------------------------------------------------------


class Instructions(Page):
	def is_displayed(player):
		return player.subsession.round_number == 1 and player.session.config['test']==0

class WaitPage0(WaitPage):
    wait_for_all_groups=True
    body_text = "Attendi"

class WaitPage1(WaitPage):
	 wait_for_all_groups=True
	 body_text = "Attendi che gli altri partecipanti facciano le loro scelte"

class Instructions2(Page):
	def is_displayed(player):
		return player.subsession.round_number == 1 and player.session.config['test']==0


class Instructions3(Page):
	def is_displayed(player):
		return player.subsession.round_number == 1 and player.session.config['test']==0


class Instructions4(Page):
	def is_displayed(player):
		return player.subsession.round_number == 1 and player.session.config['test']==0

class Control(Page):
	    form_model = 'player'
	    form_fields = ['q1', 'q2', 'q3', 'q4']
	    def is_displayed(player: Player):
	        ## ultimo round mostra risultati
	        return player.subsession.round_number == 1 and player.session.config['test']==0

	    def error_message(player: Player, values):
	        if values['q1'] != 1 and values['q2'] != 2 and values['q3'] != 2 and values['q4'] !=1: #All the answers are wrong
	            player.errors += 1
	            return 'Todas las respuestas son incorrectas '

	        if values['q1'] != 1 and values['q2'] == 2 and values['q3'] == 2 and values['q4'] ==1: # The answer to question 1 is wrong
	            player.errors += 1
	            return 'La respuesta a la pregunta 1 es incorrecta'

	        if values['q1'] == 1 and values['q2'] != 2 and values['q3'] == 2 and values['q4'] ==1: #sThe answer to question 2 is wrong
	            player.errors += 1
	            return 'La respuesta a la pregunta 2 es incorrecta'

	        if values['q1'] == 1 and values['q2'] == 2 and  values['q3'] != 2 and values['q4'] ==1: # The answer to question 3 is wrong
	            player.errors += 1
	            return 'La respuesta a la pregunta 3 es incorrecta'

	        if values['q1'] == 1 and values['q2'] == 2 and  values['q3'] == 2 and values['q4'] !=1: # The answer to question 4 is wrong
	            player.errors += 1
	            return 'La respuesta a la pregunta 4 es incorrecta'


	        if values['q1'] != 1 and values['q2'] != 2 and  values['q3'] == 2 and values['q4'] ==1: # The answers to question 1 and 2 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1 y 2 son incorrectas'

	        if values['q1'] != 1 and values['q2'] == 2 and values['q3'] != 2 and values['q4'] ==1: # he answers to question 1 and 3 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1 y 3 son incorrectas'

	        if values['q1'] != 1 and values['q2'] == 2 and values['q3'] == 2 and values['q4'] !=1: # The answers to question 1 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1 y 4 son incorrectas'


	        if values['q1'] == 1 and values['q2'] != 2 and  values['q3'] != 2 and values['q4'] ==1:  # The answers to question 2 and 3 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 2 y 3 son incorrectas'

	        if values['q1'] == 1 and values['q2'] != 2 and  values['q3'] == 2  and values['q4'] !=1: # The answers to question 2 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 2 y 4 son incorrectas'


	        if values['q1'] == 1 and values['q2'] == 2 and  values['q3'] != 2  and values['q4'] !=1: # The answers to question 3 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 3 y 4 son incorrectas'

	        if values['q1'] != 1 and values['q2'] != 2 and  values['q3'] != 2 and values['q4'] ==1: # The answers to question 1,2 and 3 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1,2 y 3 son incorrectas'

	        if values['q1'] == 1 and values['q2'] != 2 and  values['q3'] != 2  and values['q4'] !=1: # The answers to question 2,3 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 2,3 y 4 son incorrectas'

	        if values['q1'] != 1 and values['q2'] == 2 and  values['q3'] != 2  and values['q4'] !=1: # The answers to question 1,3 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1,3 y 4 son incorrectas'

	        if values['q1'] != 1 and values['q2'] != 2 and  values['q3'] == 2  and values['q4'] !=1: # The answers to question 1,2 and 4 are wrong
	            player.errors += 1
	            return 'Las respuestas a la preguntas 1,2 y 4 son incorrectas'

class Start(Page):
	def is_displayed(player):
		return player.subsession.round_number == 1 and player.session.config['test']==0


class FirstZeroOffer(Page):
	form_model = 'player'
	form_fields = ['id_content_first']

	@staticmethod
	def is_displayed(player):
		return player.roles == player.start_service

	@staticmethod
	def before_next_page(player,timeout_happened):
		player.id_content = player.id_content_first
		if player.id_content_first == 'content_1':
			player.available_content_second = 'content_2'
		elif player.id_content_first == 'content_2':
			player.available_content_second = 'content_1'
		else:
			player.available_content_second = 'nobody'


		for p in player.get_others_in_group():
			p.id_content_first = player.id_content_first
			p.available_content_second = player.available_content_second

	@staticmethod
	def vars_for_template(player):
		return dict(
			n = player.roles[len(player.roles)-1]
		)

#----------------------------------------------------------------------------

class TurnWait(WaitPage):
	pass

#----------------------------------------------------------------------------
class SecondZeroOffer(Page):
	form_model = 'player'
	form_fields = ['id_content_second']

	@staticmethod
	def is_displayed(player):
		return player.roles == player.second_service

	@staticmethod
	def vars_for_template(player):
		if player.available_content_second == 'content_1':
			t = " <option value=\"content_1\">Moviestream</option> <option value=\"nobody\">Ninguno</option>   "
		elif player.available_content_second == 'content_2':
			t = " <option value=\"content_2\">Seriestream</option> <option value=\"nobody\">Ninguno</option>   "
		else:
			t = " <option value=\"content_1\">Moviestream</option> <option value=\"content_2\">Seriestream</option> <option value=\"nobody\">Ninguno</option>   "
		return dict(
			options = t,
			n = player.roles[len(player.roles)-1],
			content = player.available_content_second
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		player.id_content = player.id_content_second
		for p in player.get_others_in_group():
			p.id_content_second = player.id_content_second


#----------------------------------------------------------------------------
class TarifChoice(Page):
	form_model = 'player'

	@staticmethod
	def get_form_fields(player):
		if player.roles == 'service_1':
			rt = ['tarif_service_1']
		else:
			rt = ['tarif_service_2']
		return rt

	@staticmethod
	def is_displayed(player):
		return player.roles == 'service_1' or player.roles == 'service_2'

	@staticmethod
	def vars_for_template(player):
		if player.roles == player.start_service:
			key = player.id_content_first
		else:
			key = player.id_content_second

		tariffa_1 = 'Tarifa 1-15GB: 15 puntos/mes + 1 punto por cada  GB extra de Moviestream + 1 punto por casa GB extra de Seriestream'
		tariffa_2 = 'Tarifa 2-20GB: 25 puntos/mes + 0.5 puntos por cada GB extra de Moviestream + 0.5 puntos por cada GB extra de Seriestream'
		tariffa_3 = 'Tarifa 3-25GB: 38 puntos/mes + 0.25 puntos por cada GB extra de Moviestream + 0.25 puntos por cada  GB extra de Seriestream'

		tariffa_11 = 'Tarifa 1-15GB: 15 puntos/mes + 0 puntos por cada GB extra de Moviestream + 1 punto por cada  GB extra de Seriestream'
		tariffa_12 = 'Tarifa 2-20GB: 25 puntos/mes + 0 puntos por cada GB extra de Moviestream + 0.5 puntos por cada GB extra de Seriestream'
		tariffa_13 = 'Tarifa 3-25GB: 38 puntos/mes + 0 puntos por cada GB extra de Moviestream + 0.25 puntos por cada  GB extra de Seriestream'

		tariffa_21 = 'Tarifa 1-15GB: 15 puntos/mes + 1 punto por cada GB extra de Moviestream + 0 puntos por cada  GB extra de Seriestream'
		tariffa_22 = 'Tarifa 2-20GB: 25 puntos/mes + 0.5 puntos por cada GB extra de Moviestream + 0 puntos por cada GB extra de Seriestream'
		tariffa_23 = 'Tarifa 3-25GB: 38 puntos/mes + 0.25 puntos por cada GB extra de Moviestream + 0 puntos por cada  GB extra de Seriestream'

		if key == 'nobody':
			t = " <option value=1>" + tariffa_1 + "</option> <option value=2>" + tariffa_2 + "</option>   <option value=3>" + tariffa_3 + "</option> "
		elif key == 'content_1':
			t = " <option value=1>" + tariffa_11 + "</option> <option value=2>" + tariffa_12 + "</option> <option value=3>" + tariffa_13 + "</option>"
		else:
			t = " <option value=1>" + tariffa_21 + "</option> <option value=2>" + tariffa_22 + "</option> <option value=3>" + tariffa_23 + "</option>"

		if player.roles == 'service_1':
			rt = 'tarif_service_1'
		else:
			rt = 'tarif_service_2'
		return dict(
			options = t,
			name_var = rt,
			n = player.roles[len(player.roles)-1]
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		if player.roles == 'service_1':
			for p in player.get_others_in_group():
				p.tarif_service_1 = player.tarif_service_1
		else:
			for p in player.get_others_in_group():
				p.tarif_service_2 = player.tarif_service_2


#----------------------------------------------------------------------------
class ContentPrice(Page):
	form_model = 'player'

	@staticmethod
	def get_form_fields(player):
		if player.roles == 'content_1':
			rt = ['price_content_1']
		else:
			rt = ['price_content_2']
		return rt

	@staticmethod
	def is_displayed(player):
		return player.roles == 'content_1' or player.roles == 'content_2'

	@staticmethod
	def vars_for_template(player):
		if player.roles == 'content_1':
			rt = 'price_content_1'
		else:
			rt = 'price_content_2'

		return dict(
			name_var = rt,
			n = player.roles[len(player.roles)-1]
		)

	@staticmethod
	def before_next_page(player,timeout_happened):
		if player.roles == 'content_1':
			for p in player.get_others_in_group():
				p.price_content_1 = player.price_content_1
		else:
			for p in player.get_others_in_group():
				p.price_content_2 = player.price_content_2


#----------------------------------------------------------------------------

class DemandWait(WaitPage):
	wait_for_all_groups = False
	after_all_players_arrive = get_demand

#----------------------------------------------------------------------------
class Debug(Page):
	form_model = 'player'

	@staticmethod
	def vars_for_template(player):
		mygrp = player.group
		get_demand(mygrp)
		return dict(

		)

class Results(Page):

	@staticmethod
	def vars_for_template(player):

		if player.roles == 'content_1':
			r = 'Moviestream'
			ch = player.price_content_1
		elif player.roles == 'content_2':
			r = 'Seriestream'
			ch = player.price_content_2
		elif player.roles == 'service_1':
			r = 'Prontophone'
			ch = player.tarif_service_1
		elif player.roles == 'service_2':
			r = 'Cellecom'
			ch = player.tarif_service_2


		my_tr = "<tr><th>YO: " + r + "</th><td>" + str(ch) + "</td><td>" + str(round(player.profit,2)) + "</td><td>" + str(round(player.participant.vars['cum_payoff'],2)) + "</td></tr>"

		other_tr = ""
		for p in player.get_others_in_group():
			if p.roles == 'content_1':
				r = 'Moviestream'
				ch = player.price_content_1
			elif p.roles == 'content_2':
				r = 'Seriestream'
				ch = player.price_content_2
			elif p.roles == 'service_1':
				r = 'Prontophone'
				ch = player.tarif_service_1
			elif p.roles == 'service_2':
				r = 'Cellecom'
				ch = player.tarif_service_2

			other_tr = other_tr + "<tr><td>" + r + "</td><td>" + str(ch) + "</td><td>" + str(round(p.profit,2)) + "</td><td>" + str(round(p.participant.vars['cum_payoff'],2)) + "</td></tr>"


		return dict(
			cumulated = player.participant.vars['cum_payoff'],
			tr = my_tr + other_tr,
			history = player.participant.vars["history"],
			history_accordion = player.participant.vars["history"]
		)


	@staticmethod
	def before_next_page(player,timeout_happened):

		if player.roles == 'content_1':
			ch = player.price_content_1
			r = 'Moviestream'
		elif player.roles == 'content_2':
			ch = player.price_content_2
			r = 'Seriestream'
		elif player.roles == 'service_1':
			ch = player.tarif_service_1
			r = 'Prontophone'
		elif player.roles == 'service_2':
			ch = player.tarif_service_2
			r = 'Cellecom'


		my_tr = "<tr><th>YO: " + r + "</th><td>" + str(ch) + "</td><td>" + str(round(player.profit,2)) + "</td><td>" + str(round(player.participant.vars['cum_payoff'],2)) + "</td></tr>"

		other_tr = ""
		for p in player.get_others_in_group():
			if p.roles == 'content_1':
				ch = player.price_content_1
				r = 'Moviestream'
			elif p.roles == 'content_2':
				ch = player.price_content_2
				r = 'Seriestream'
			elif p.roles == 'service_1':
				ch = player.tarif_service_1
				r = 'Prontophone'
			elif p.roles == 'service_2':
				ch = player.tarif_service_2
				r = 'Cellecom'

			other_tr = other_tr + "<tr><td>" + r + "</td><td>" + str(ch) + "</td><td>" + str(round(p.profit,2)) + "</td><td>" + str(round(p.participant.vars['cum_payoff'],2)) + "</td></tr>"


		# player.participant.vars['history'] = player.participant.vars['history'] + "<hr>" +  "<tr><th colspan=\"4\">ROUND " + str(player.round_number) + "</th></tr>" + my_tr + other_tr


		a1 =  "<div class=\"accordion-item\">"
		a2 =  "<h2 class=\"accordion-header\" id=\"headingOne\">"
		a3 =  "<button class=\"accordion-button\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse" + str(player.round_number) + "\" aria-expanded=\"true\" aria-controls=\"collapseOne\">"
		a4 =  "Ronda " +  str(player.round_number)
		a5 =  "</button>"
		a6 =  "</h2>"
		a7 =  "<div id=\"collapse" + str(player.round_number) + "\" class=\"accordion-collapse collapse\" aria-labelledby=\"headingOne\" data-bs-parent=\"#accordionExample\">"
		a8 =  "<div class=\"accordion-body\">"
		a9 =  "<table class=\"table table-striped table-hover\">"
		a10 =  "<thead>"
		a11 =  "<th colspan=\"4\">""</th>"
		a12 =  "</thead>"
		a13 =  "<thead>"
		a14 =  "<th>Ruolo</th>"
		a15 =  "<th>Scelta</th>"
		a16 =  "<th>Payoff</th>"
		a17 =  "<th>Payoff Cumulato</th>"
		a18 =  "</thead>"
		a19 =  my_tr + other_tr
		a20 =  "</table>"
		a21 =  "</div>"
		a22 =  "</div>"
		a23 =  "</div>"

		my_accordion = a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20 + a21 + a22

		player.participant.vars['history'] = my_accordion + player.participant.vars['history']


class Start_exp(Page):
	def is_displayed(player):
		return player.subsession.round_number == C.NUM_ROUNDS
	def before_next_page(player,timeout_happened):
		player.participant.vars['history']=""
		player.participant.vars['cum_payoff']=0
		player.payoff=0


page_sequence = [Instructions,WaitPage0,Instructions2,WaitPage0, Instructions3,WaitPage0,Instructions4,WaitPage0,Control,WaitPage0, Start,FirstZeroOffer,TurnWait,SecondZeroOffer,TurnWait,TarifChoice,ContentPrice,DemandWait,Results, Start_exp]
